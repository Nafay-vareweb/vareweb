'use client';

import { useEffect, useRef } from 'react';
import Link from 'next/link';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import PageDecorations from '@/components/PageDecorations';
import {
  ArrowRight, Users, Heart, Clock, Target, Lightbulb, Shield, Award,
  Briefcase, Trophy, Star, Medal, Globe,
  BookOpen, Sparkles,
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const stats = [
  { value: '15,000+', label: 'Projects Delivered', icon: Briefcase },
  { value: '98%', label: 'Client Satisfaction', icon: Heart },
  { value: '24/7', label: 'Live Support', icon: Clock },
  { value: '50+', label: 'Team Members', icon: Users },
];

const values = [
  { icon: Lightbulb, title: 'Innovation First', desc: 'We push creative boundaries and embrace new technologies to deliver solutions that stand out in the market.' },
  { icon: Heart, title: 'Client Obsessed', desc: 'Every decision is driven by what creates the most value for our clients and their end users.' },
  { icon: Shield, title: 'Quality Guaranteed', desc: 'We never compromise on quality. Every pixel, every line of code, every interaction is crafted to perfection.' },
  { icon: Target, title: 'Results Driven', desc: 'Beautiful design means nothing without results. We focus on measurable outcomes that drive real business growth.' },
];

const milestones = [
  { year: '2014', title: 'Founded in Dallas, TX', desc: 'Started with a small team of 3 passionate designers with a vision to transform digital experiences.' },
  { year: '2016', title: 'First 100 Clients', desc: 'Reached our first major milestone serving 100 businesses across the United States.' },
  { year: '2018', title: 'International Expansion', desc: 'Expanded operations to serve clients in Europe and Asia, opening offices in London and Dubai.' },
  { year: '2020', title: 'Digital Transformation Leader', desc: 'Helped over 200 businesses pivot to digital during the global pandemic.' },
  { year: '2022', title: '1,000+ Projects Delivered', desc: 'Surpassed 1,000 successfully completed projects with a 98% client satisfaction rate.' },
  { year: '2024', title: 'AI-Powered Solutions', desc: 'Launched our AI integration services, helping clients leverage cutting-edge technology.' },
];

const awards = [
  { title: 'Best Web Design Agency 2024', org: 'Global Digital Awards', Icon: Trophy },
  { title: 'Top 10 Creative Agencies', org: 'Forbes Magazine', Icon: Star },
  { title: 'Excellence in UX Design', org: 'Awwwards', Icon: Award },
  { title: 'Innovation in Digital Marketing', org: 'DMI Awards', Icon: Medal },
  { title: 'Best E-Commerce Solution', org: 'Commerce Awards', Icon: Trophy },
  { title: 'Customer Choice Award', org: 'Clutch.co', Icon: Star },
];

const partnersRow1 = ['Google', 'Microsoft', 'Amazon', 'Apple', 'Tesla', 'Meta', 'Netflix', 'Spotify'];
const partnersRow2 = ['Adobe', 'Samsung', 'Nike', 'Airbnb', 'Uber', 'Bloomberg', 'NASA', 'MIT'];

const cultureCards = [
  { icon: Globe, title: 'Remote-First Culture', desc: 'Work from anywhere in the world. Our distributed team spans 15+ countries, bringing diverse perspectives to every project.' },
  { icon: BookOpen, title: 'Continuous Learning', desc: 'We invest in our team with dedicated learning budgets, conference passes, and weekly knowledge-sharing sessions.' },
  { icon: Sparkles, title: 'Creative Freedom', desc: 'Every team member has a voice. We encourage experimentation, innovation, and thinking outside the box.' },
  { icon: Heart, title: 'Work-Life Balance', desc: 'Flexible hours, unlimited PTO, and a genuine focus on well-being. Happy teams create amazing work.' },
];



export default function AboutPage() {
  const heroRef = useRef<HTMLElement>(null);
  const storyRef = useRef<HTMLElement>(null);
  const statsRef = useRef<HTMLElement>(null);
  const valuesRef = useRef<HTMLElement>(null);
  const timelineRef = useRef<HTMLElement>(null);
  const awardsRef = useRef<HTMLElement>(null);
  const partnersRef = useRef<HTMLElement>(null);
  const cultureRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Hero
      if (heroRef.current) {
        gsap.fromTo(
          heroRef.current.querySelectorAll('.hero-anim'),
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, stagger: 0.15, ease: 'power3.out' }
        );
      }

      // Story
      if (storyRef.current) {
        gsap.fromTo(
          storyRef.current.querySelectorAll('.story-anim'),
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.6, stagger: 0.15, ease: 'power3.out', scrollTrigger: { trigger: storyRef.current, start: 'top 75%' } }
        );
      }

      // Stats
      if (statsRef.current) {
        gsap.fromTo(
          statsRef.current.querySelectorAll('.stat-card'),
          { y: 40, opacity: 0, scale: 0.9 },
          { y: 0, opacity: 1, scale: 1, duration: 0.5, stagger: 0.1, ease: 'power3.out', scrollTrigger: { trigger: statsRef.current, start: 'top 80%' } }
        );
      }

      // Values
      if (valuesRef.current) {
        gsap.fromTo(
          valuesRef.current.querySelectorAll('.value-card'),
          { y: 50, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.5, stagger: 0.1, ease: 'power3.out', scrollTrigger: { trigger: valuesRef.current.querySelector('.values-grid'), start: 'top 80%' } }
        );
      }

      // Timeline - center line draws in, items stagger from sides
      if (timelineRef.current) {
        const centerLine = timelineRef.current.querySelector('.timeline-center-line');
        if (centerLine) {
          gsap.fromTo(
            centerLine,
            { scaleY: 0, transformOrigin: 'top center' },
            {
              scaleY: 1,
              transformOrigin: 'top center',
              duration: 1.2,
              ease: 'power2.out',
              scrollTrigger: {
                trigger: timelineRef.current,
                start: 'top 70%',
                end: 'bottom 40%',
                scrub: 0.6,
              },
            }
          );
        }

        // Each timeline item slides from alternating sides with glow
        const items = timelineRef.current.querySelectorAll('.timeline-item');
        items.forEach((item, i) => {
          const isLeft = i % 2 === 0;
          const card = item.querySelector('.timeline-card');
          const badge = item.querySelector('.timeline-badge');

          // Card slides in from side
          gsap.fromTo(
            card,
            { x: isLeft ? -60 : 60, opacity: 0 },
            {
              x: 0,
              opacity: 1,
              duration: 0.7,
              ease: 'power3.out',
              scrollTrigger: {
                trigger: item,
                start: 'top 80%',
              },
            }
          );

          // Card content fades in with delay
          const content = item.querySelectorAll('.timeline-content > *');
          gsap.fromTo(
            content,
            { y: 15, opacity: 0 },
            {
              y: 0,
              opacity: 1,
              duration: 0.4,
              stagger: 0.08,
              ease: 'power2.out',
              scrollTrigger: {
                trigger: item,
                start: 'top 75%',
              },
              delay: 0.15,
            }
          );

          // Year badge scales in with pop
          if (badge) {
            gsap.fromTo(
              badge,
              { scale: 0, opacity: 0 },
              {
                scale: 1,
                opacity: 1,
                duration: 0.5,
                ease: 'back.out(2.5)',
                scrollTrigger: {
                  trigger: item,
                  start: 'top 82%',
                },
              }
            );
          }

          // Subtle glow pulse on visible items
          gsap.to(item, {
            boxShadow: '0 0 30px rgba(58, 26, 112, 0.1), 0 0 60px rgba(58, 26, 112, 0.05)',
            duration: 0.6,
            ease: 'power1.inOut',
            scrollTrigger: {
              trigger: item,
              start: 'top 70%',
              end: 'top 30%',
              scrub: 1,
              toggleActions: 'play reverse play reverse',
            },
          });
        });
      }

      // Awards
      if (awardsRef.current) {
        gsap.fromTo(
          awardsRef.current.querySelectorAll('.award-card'),
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.5, stagger: 0.1, ease: 'power3.out', scrollTrigger: { trigger: awardsRef.current.querySelector('.awards-grid'), start: 'top 80%' } }
        );
      }

      // Partners
      if (partnersRef.current) {
        gsap.fromTo(
          partnersRef.current.querySelectorAll('.partners-header'),
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.6, stagger: 0.1, ease: 'power3.out', scrollTrigger: { trigger: partnersRef.current, start: 'top 80%' } }
        );
      }

      // Culture
      if (cultureRef.current) {
        gsap.fromTo(
          cultureRef.current.querySelectorAll('.culture-card'),
          { y: 50, opacity: 0, scale: 0.95 },
          { y: 0, opacity: 1, scale: 1, duration: 0.6, stagger: 0.12, ease: 'power3.out', scrollTrigger: { trigger: cultureRef.current.querySelector('.culture-grid'), start: 'top 80%' } }
        );
      }
    });
    return () => ctx.revert();
  }, []);

  return (
    <>
      <Navigation />
      <PageDecorations />
      <main>
        {/* Hero */}
        <section ref={heroRef} className="relative pt-32 pb-24 overflow-hidden gradient-purple-dark">
          <div className="absolute inset-0">
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(123,77,187,0.3),transparent_50%)]" />
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,rgba(58,26,112,0.4),transparent_50%)]" />
            <div className="absolute top-20 left-10 w-72 h-72 bg-purple-500/10 rounded-full blur-3xl" />
            <div className="absolute bottom-20 right-10 w-96 h-96 bg-purple-400/10 rounded-full blur-3xl" />
          </div>
          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <span className="hero-anim inline-flex items-center px-3 py-1 rounded-full glass-effect text-white/90 text-sm font-medium mb-6 opacity-0">
              <Users className="w-4 h-4 mr-1.5" /> Who We Are
            </span>
            <h1 className="hero-anim text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-6 opacity-0">
              About <span className="text-transparent bg-clip-text bg-gradient-to-r from-vare-gold to-yellow-300">Us</span>
            </h1>
            <p className="hero-anim max-w-2xl mx-auto text-lg text-white/70 leading-relaxed opacity-0">
              We are a passionate team of designers, developers, and strategists dedicated to crafting exceptional digital experiences that drive real business results.
            </p>
          </div>
        </section>

        {/* Our Story */}
        <section ref={storyRef} className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
              <div>
                <span className="story-anim inline-flex items-center px-3 py-1 rounded-full bg-vare-ice text-vare-purple text-sm font-medium mb-4">
                  <Award className="w-4 h-4 mr-1.5" /> Our Story
                </span>
                <h2 className="story-anim text-3xl md:text-4xl font-bold text-vare-slate mb-6">
                  A Decade of <span className="text-gradient">Digital Excellence</span>
                </h2>
                <p className="story-anim text-vare-gray leading-relaxed mb-4">
                  Founded with a simple mission to help businesses succeed online, VareWeb has grown into a full-service digital agency trusted by thousands of clients worldwide. What started as a small web design studio has evolved into a powerhouse team of creative thinkers and technical innovators.
                </p>
                <p className="story-anim text-vare-gray leading-relaxed mb-4">
                  Over the years, we have completed more than 15,000 projects across diverse industries, from startups to Fortune 500 companies. Our approach combines cutting-edge technology with time-tested design principles to deliver solutions that are not only beautiful but also perform exceptionally well.
                </p>
                <p className="story-anim text-vare-gray leading-relaxed">
                  We believe that great design is more than aesthetics. It is about solving real problems, creating meaningful connections, and driving measurable growth. That is why every project we take on begins with understanding your unique challenges and goals.
                </p>
              </div>
              <div className="story-anim relative">
                <div className="aspect-square rounded-3xl gradient-purple-dark overflow-hidden relative">
                  <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(123,77,187,0.3),transparent_70%)]" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-8xl font-bold text-white/10 mb-2">VW</div>
                      <p className="text-white/30 text-sm">Since 2014</p>
                    </div>
                  </div>
                  <div className="absolute bottom-6 left-6 right-6 grid grid-cols-2 gap-4">
                    <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 text-center">
                      <div className="text-2xl font-bold text-white">10+</div>
                      <div className="text-white/60 text-xs">Years Active</div>
                    </div>
                    <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 text-center">
                      <div className="text-2xl font-bold text-white">40+</div>
                      <div className="text-white/60 text-xs">Countries Served</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Stats */}
        <section ref={statsRef} className="py-20 bg-vare-ice">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
              {stats.map((stat, i) => (
                <div key={i} className="stat-card bg-white rounded-2xl p-8 border border-gray-100 text-center hover:shadow-lg hover:border-vare-purple/20 transition-all duration-300">
                  <div className="w-14 h-14 rounded-xl bg-vare-ice flex items-center justify-center mx-auto mb-4">
                    <stat.icon className="w-7 h-7 text-vare-purple" />
                  </div>
                  <div className="text-3xl font-bold text-vare-slate mb-1">{stat.value}</div>
                  <div className="text-vare-gray text-sm">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Our Values */}
        <section ref={valuesRef} className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <span className="inline-flex items-center px-3 py-1 rounded-full bg-vare-ice text-vare-purple text-sm font-medium mb-4">
                <Heart className="w-4 h-4 mr-1.5" /> What Drives Us
              </span>
              <h2 className="text-3xl md:text-4xl font-bold text-vare-slate mb-4">
                Our Core <span className="text-gradient">Values</span>
              </h2>
              <p className="text-vare-gray max-w-2xl mx-auto text-lg">
                These principles guide everything we do, from the first client meeting to the final launch.
              </p>
            </div>
            <div className="values-grid grid grid-cols-1 md:grid-cols-2 gap-8">
              {values.map((value, i) => (
                <div key={i} className="value-card group bg-white rounded-2xl p-8 border border-gray-100 hover:border-vare-purple/20 hover:shadow-xl hover:shadow-purple-500/5 transition-all duration-500">
                  <div className="w-14 h-14 rounded-xl bg-vare-ice flex items-center justify-center mb-6 group-hover:bg-vare-purple transition-colors duration-300">
                    <value.icon className="w-7 h-7 text-vare-purple group-hover:text-white transition-colors duration-300" />
                  </div>
                  <h3 className="text-xl font-bold text-vare-slate mb-3">{value.title}</h3>
                  <p className="text-vare-gray text-sm leading-relaxed">{value.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Our Journey - Timeline */}
        <section ref={timelineRef} className="py-24 bg-white">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <span className="inline-flex items-center px-3 py-1 rounded-full bg-vare-ice text-vare-purple text-sm font-medium mb-4">
                <Clock className="w-4 h-4 mr-1.5" /> Our Journey
              </span>
              <h2 className="text-3xl md:text-4xl font-bold text-vare-slate mb-4">
                Key <span className="text-gradient">Milestones</span>
              </h2>
              <p className="text-vare-gray max-w-2xl mx-auto text-lg">
                Key milestones in our decade of digital excellence
              </p>
            </div>
            <div className="relative">
              {/* Center line - animated draw in via GSAP */}
              <div className="timeline-center-line absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-vare-purple via-vare-purple-light to-vare-gold md:-translate-x-px" />
              <div className="space-y-12">
                {milestones.map((m, i) => {
                  const isLeft = i % 2 === 0;
                  return (
                    <div key={i} className="timeline-item relative flex items-start gap-6 md:gap-0">
                      {/* Year badge - desktop only, with pop animation */}
                      <div className="timeline-badge hidden md:flex absolute left-1/2 top-6 -translate-x-1/2 z-10 w-12 h-12 rounded-full bg-gradient-to-br from-vare-purple to-vare-purple-light items-center justify-center text-white text-xs font-bold shadow-lg shadow-purple-500/30" style={{ opacity: 0 }}>
                        {m.year.slice(2)}
                      </div>
                      {/* Content */}
                      <div className={`ml-12 md:ml-0 md:w-[calc(50%-2rem)] ${isLeft ? 'md:mr-auto md:pr-8 md:text-right' : 'md:ml-auto md:pl-8 md:text-left'}`}>
                        <div className="timeline-card bg-white rounded-2xl p-6 border border-gray-100 hover:border-vare-purple/20 hover:shadow-xl hover:shadow-purple-500/5 transition-all duration-300" style={{ opacity: 0 }}>
                          <div className="timeline-content">
                            {/* Mobile year badge */}
                            <div className="md:hidden inline-flex items-center px-3 py-1 rounded-full bg-gradient-to-r from-vare-purple to-vare-purple-light text-white text-xs font-bold mb-3">
                              {m.year}
                            </div>
                            <div className="hidden md:block text-sm font-bold text-vare-purple mb-1">{m.year}</div>
                            <h3 className="text-lg font-bold text-vare-slate mb-2">{m.title}</h3>
                            <p className="text-vare-gray text-sm leading-relaxed">{m.desc}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </section>

        {/* Awards & Recognition */}
        <section ref={awardsRef} className="py-24 bg-vare-ice">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <span className="inline-flex items-center px-3 py-1 rounded-full bg-white text-vare-purple text-sm font-medium mb-4">
                <Trophy className="w-4 h-4 mr-1.5" /> Recognition
              </span>
              <h2 className="text-3xl md:text-4xl font-bold text-vare-slate mb-4">
                Awards & <span className="text-gradient">Recognition</span>
              </h2>
              <p className="text-vare-gray max-w-2xl mx-auto text-lg">
                Our work speaks for itself
              </p>
            </div>
            <div className="awards-grid grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {awards.map((award, i) => (
                <div key={i} className="award-card group relative bg-white rounded-2xl p-8 border border-gray-100 hover:border-vare-purple/20 hover:shadow-xl hover:shadow-purple-500/5 transition-all duration-300 overflow-hidden">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-vare-gold/10 to-transparent rounded-bl-full" />
                  <div className="relative">
                    <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-vare-purple to-vare-purple-light flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                      <award.Icon className="w-7 h-7 text-white" />
                    </div>
                    <h3 className="text-lg font-bold text-vare-slate mb-2">{award.title}</h3>
                    <p className="text-vare-gray text-sm">{award.org}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Trusted by Industry Leaders - Partners */}
        <section ref={partnersRef} className="py-24 bg-white overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
            <div className="text-center">
              <span className="partners-header inline-flex items-center px-3 py-1 rounded-full bg-vare-ice text-vare-purple text-sm font-medium mb-4 opacity-0">
                <Shield className="w-4 h-4 mr-1.5" /> Trusted Partners
              </span>
              <h2 className="partners-header text-3xl md:text-4xl font-bold text-vare-slate mb-4 opacity-0">
                Trusted by <span className="text-gradient">Industry Leaders</span>
              </h2>
              <p className="partners-header text-vare-gray max-w-2xl mx-auto text-lg opacity-0">
                We&apos;re proud to partner with amazing companies worldwide
              </p>
            </div>
          </div>
          <div className="relative">
            {/* Fade edges */}
            <div className="absolute left-0 top-0 bottom-0 w-24 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none" />
            <div className="absolute right-0 top-0 bottom-0 w-24 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none" />
            {/* Row 1 - scrolling left */}
            <div className="mb-4 group">
              <div className="flex animate-scroll-left gap-8 w-max hover:[animation-play-state:paused]">
                {[...partnersRow1, ...partnersRow1].map((name, i) => (
                  <div key={i} className="flex-shrink-0 flex items-center justify-center px-8 py-4 bg-vare-ice/50 rounded-2xl border border-gray-100 min-w-[160px]">
                    <span className="text-xl font-bold text-vare-slate/70 whitespace-nowrap">{name}</span>
                  </div>
                ))}
              </div>
            </div>
            {/* Row 2 - scrolling right */}
            <div className="group">
              <div className="flex animate-scroll-right gap-8 w-max hover:[animation-play-state:paused]">
                {[...partnersRow2, ...partnersRow2].map((name, i) => (
                  <div key={i} className="flex-shrink-0 flex items-center justify-center px-8 py-4 bg-vare-ice/50 rounded-2xl border border-gray-100 min-w-[160px]">
                    <span className="text-xl font-bold text-vare-slate/70 whitespace-nowrap">{name}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <style jsx>{`
            @keyframes scrollLeft {
              0% { transform: translateX(0); }
              100% { transform: translateX(-50%); }
            }
            @keyframes scrollRight {
              0% { transform: translateX(-50%); }
              100% { transform: translateX(0); }
            }
            .animate-scroll-left {
              animation: scrollLeft 30s linear infinite;
            }
            .animate-scroll-right {
              animation: scrollRight 30s linear infinite;
            }
          `}</style>
        </section>

        {/* Culture & Work Environment */}
        <section ref={cultureRef} className="py-24 bg-vare-ice">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <span className="inline-flex items-center px-3 py-1 rounded-full bg-white text-vare-purple text-sm font-medium mb-4">
                <Heart className="w-4 h-4 mr-1.5" /> Our Culture
              </span>
              <h2 className="text-3xl md:text-4xl font-bold text-vare-slate mb-4">
                Life at <span className="text-gradient">VareWeb</span>
              </h2>
              <p className="text-vare-gray max-w-2xl mx-auto text-lg">
                Where creativity meets collaboration
              </p>
            </div>
            <div className="culture-grid grid grid-cols-1 md:grid-cols-2 gap-8">
              {cultureCards.map((card, i) => (
                <div key={i} className="culture-card group relative bg-white rounded-2xl p-8 border border-gray-100 hover:border-vare-purple/20 hover:shadow-xl hover:shadow-purple-500/5 transition-all duration-500 overflow-hidden">
                  <div className="absolute top-0 left-0 w-32 h-32 bg-gradient-to-br from-vare-purple/5 to-vare-gold/5 rounded-br-full transition-all duration-500 group-hover:w-48 group-hover:h-48" />
                  <div className="relative">
                    <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-vare-ice to-vare-purple/10 flex items-center justify-center mb-6 group-hover:bg-gradient-to-br group-hover:from-vare-purple group-hover:to-vare-purple-light transition-all duration-300">
                      <card.icon className="w-7 h-7 text-vare-purple group-hover:text-white transition-colors duration-300" />
                    </div>
                    <h3 className="text-xl font-bold text-vare-slate mb-3">{card.title}</h3>
                    <p className="text-vare-gray text-sm leading-relaxed">{card.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA - Let's Build Something Amazing */}
        <section className="relative py-24 overflow-hidden bg-vare-ice">
          <div className="absolute inset-0">
            <div className="absolute top-0 right-0 w-96 h-96 bg-vare-purple/5 rounded-full blur-3xl" />
            <div className="absolute bottom-0 left-0 w-72 h-72 bg-vare-gold/5 rounded-full blur-3xl" />
          </div>
          <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="gradient-purple rounded-3xl p-10 sm:p-14 lg:p-16 relative overflow-hidden">
              {/* Decorative elements */}
              <div className="absolute top-0 right-0 w-40 h-40 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2" />
              <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/2" />
              <div className="absolute top-1/2 right-8 -translate-y-1/2 w-20 h-20 border-2 border-white/10 rounded-full" />
              <div className="absolute bottom-8 right-32 w-12 h-12 border border-white/10 rounded-full" />

              <div className="relative text-center">
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 text-white/90 text-sm font-medium mb-6">
                  <Sparkles className="w-4 h-4 text-vare-gold" />
                  Let&apos;s Create Together
                </div>
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-5 leading-tight">
                  Your Vision, Our{' '}
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-vare-gold to-yellow-300">Expertise</span>
                </h2>
                <p className="text-white/70 text-base sm:text-lg mb-8 max-w-xl mx-auto leading-relaxed">
                  Whether you need a complete brand overhaul or a simple website refresh, our team is ready to bring your ideas to life with precision and creativity.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                  <Link
                    href="/contact"
                    className="inline-flex items-center px-8 py-4 text-base font-semibold text-vare-purple bg-white rounded-xl hover:shadow-2xl hover:shadow-white/25 transform hover:-translate-y-1 transition-all duration-300"
                  >
                    Start a Conversation <ArrowRight className="ml-2 w-5 h-5" />
                  </Link>
                  <Link
                    href="/careers"
                    className="inline-flex items-center px-8 py-4 text-base font-medium text-white border-2 border-white/25 rounded-xl hover:bg-white/10 hover:border-white/40 transition-all duration-300"
                  >
                    Join Our Team <Users className="ml-2 w-5 h-5" />
                  </Link>
                </div>
                <div className="mt-10 flex flex-wrap justify-center gap-6 sm:gap-10">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white">15K+</div>
                    <div className="text-white/50 text-xs mt-1">Projects Done</div>
                  </div>
                  <div className="w-px h-10 bg-white/10" />
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white">98%</div>
                    <div className="text-white/50 text-xs mt-1">Satisfaction</div>
                  </div>
                  <div className="w-px h-10 bg-white/10" />
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white">50+</div>
                    <div className="text-white/50 text-xs mt-1">Team Experts</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
