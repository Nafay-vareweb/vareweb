'use client';

import { useEffect, useRef } from 'react';
import Link from 'next/link';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import PageDecorations from '@/components/PageDecorations';
import {
  ArrowRight,
  CheckCircle2,
  Sparkles,
  ChevronDown,
  Check,
  X,
  ShieldCheck,
  UserCog,
  Puzzle,
  HeadphonesIcon,
  FileCheck,
  Phone,
} from 'lucide-react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

gsap.registerPlugin(ScrollTrigger);

const pricingPlans = [
  {
    name: 'Starter',
    price: '$299',
    period: '/project',
    desc: 'Perfect for small businesses getting started online.',
    features: ['Custom Website Design', 'Up to 5 Pages', 'Mobile Responsive', 'Contact Form', '1 Month Support', 'Basic SEO Setup'],
    popular: false,
  },
  {
    name: 'Professional',
    price: '$699',
    period: '/project',
    desc: 'Ideal for growing businesses that need more features.',
    features: ['Custom Website Design', 'Up to 15 Pages', 'Mobile Responsive', 'CMS Integration', 'Advanced SEO', '6 Months Support', 'eCommerce Ready', 'Analytics Setup'],
    popular: true,
  },
  {
    name: 'Enterprise',
    price: '$1,499',
    period: '/project',
    desc: 'For established businesses needing a complete solution.',
    features: ['Custom Web Application', 'Unlimited Pages', 'Custom Functionality', 'API Integrations', 'Premium SEO', '12 Months Support', 'Performance Optimization', 'Security Audit', 'Dedicated Manager'],
    popular: false,
  },
];

const comparisonFeatures = [
  { feature: 'Custom Pages', starter: 'Up to 5', professional: 'Up to 15', enterprise: 'Unlimited' },
  { feature: 'Responsive Design', starter: 'check', professional: 'check', enterprise: 'check' },
  { feature: 'SEO Optimization', starter: 'Basic', professional: 'Advanced', enterprise: 'Full Suite' },
  { feature: 'SSL Certificate', starter: 'check', professional: 'check', enterprise: 'check' },
  { feature: 'CMS Integration', starter: false, professional: 'check', enterprise: 'check' },
  { feature: 'Contact Forms', starter: '1 Form', professional: 'Unlimited', enterprise: 'Unlimited' },
  { feature: 'Analytics', starter: 'Basic', professional: 'Advanced', enterprise: 'Custom Dashboard' },
  { feature: 'Social Media Integration', starter: false, professional: 'check', enterprise: 'check' },
  { feature: 'Email Support', starter: 'check', professional: 'check', enterprise: 'check' },
  { feature: 'Phone Support', starter: false, professional: 'check', enterprise: 'Priority' },
  { feature: 'Revision Rounds', starter: '2', professional: '5', enterprise: 'Unlimited' },
  { feature: 'Delivery Time', starter: '2 Weeks', professional: '3 Weeks', enterprise: '4 Weeks' },
];

const faqs = [
  {
    question: 'How long does it take to build a website?',
    answer: 'Typical project timelines range from 2-8 weeks depending on complexity. A simple 5-page website can be delivered in as little as 5 business days, while complex web applications may take 8-12 weeks. We provide a detailed timeline during our initial consultation.',
  },
  {
    question: 'Do you offer ongoing maintenance and support?',
    answer: 'Yes! All our plans include post-launch support (1 month for Starter, 6 months for Professional, 12 months for Enterprise). We also offer dedicated maintenance packages for ongoing updates, security patches, and performance optimization.',
  },
  {
    question: 'Can I make changes after the project is delivered?',
    answer: 'Absolutely. During your support period, minor revisions and bug fixes are included at no extra cost. For significant changes or new features, we offer competitive hourly rates or can set up a retainer agreement.',
  },
  {
    question: 'What technologies do you use?',
    answer: 'We use modern, industry-standard technologies including Next.js, React, TypeScript, Tailwind CSS, and various CMS platforms. For eCommerce, we work with Shopify, WooCommerce, and custom solutions. We choose the best tech stack for each project\'s specific needs.',
  },
  {
    question: 'Do you provide hosting and domain services?',
    answer: 'While we don\'t directly provide hosting, we partner with top-tier hosting providers and can manage your hosting setup, domain configuration, SSL certificates, and DNS management as part of your project.',
  },
  {
    question: 'What is your payment process?',
    answer: 'We typically work with a 50% upfront deposit and 50% upon completion. For larger projects, we can arrange milestone-based payments. We accept credit cards, bank transfers, and PayPal for your convenience.',
  },
];

const enterpriseBenefits = [
  {
    icon: UserCog,
    title: 'Dedicated Account Manager',
    description: 'A personal account manager who understands your business goals and ensures seamless project delivery.',
  },
  {
    icon: Puzzle,
    title: 'Custom Integrations',
    description: 'Tailored third-party integrations with your existing tools — CRM, ERP, payment gateways, and more.',
  },
  {
    icon: HeadphonesIcon,
    title: 'Priority Support',
    description: 'Skip the queue with dedicated priority support channels and faster response times around the clock.',
  },
  {
    icon: FileCheck,
    title: 'SLA Guarantee',
    description: 'Backed by a formal Service Level Agreement ensuring uptime, performance benchmarks, and quality standards.',
  },
];

export default function PricingPage() {
  const heroRef = useRef<HTMLElement>(null);
  const pricingRef = useRef<HTMLElement>(null);
  const comparisonRef = useRef<HTMLElement>(null);
  const guaranteeRef = useRef<HTMLElement>(null);
  const enterpriseRef = useRef<HTMLElement>(null);
  const faqRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (heroRef.current) {
        gsap.fromTo(
          heroRef.current.querySelectorAll('.hero-anim'),
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, stagger: 0.15, ease: 'power3.out' }
        );
      }

      if (pricingRef.current) {
        gsap.fromTo(
          pricingRef.current.querySelector('.section-header'),
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, ease: 'power3.out', scrollTrigger: { trigger: pricingRef.current, start: 'top 75%' } }
        );
        gsap.fromTo(
          pricingRef.current.querySelectorAll('.pricing-card'),
          { y: 60, opacity: 0, scale: 0.95 },
          { y: 0, opacity: 1, scale: 1, duration: 0.6, stagger: 0.15, ease: 'power3.out', scrollTrigger: { trigger: pricingRef.current.querySelector('.pricing-grid'), start: 'top 80%' } }
        );
      }

      if (comparisonRef.current) {
        gsap.fromTo(
          comparisonRef.current.querySelector('.section-header'),
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, ease: 'power3.out', scrollTrigger: { trigger: comparisonRef.current, start: 'top 75%' } }
        );
        gsap.fromTo(
          comparisonRef.current.querySelectorAll('.comparison-row'),
          { x: -30, opacity: 0 },
          { x: 0, opacity: 1, duration: 0.4, stagger: 0.05, ease: 'power2.out', scrollTrigger: { trigger: comparisonRef.current.querySelector('.comparison-table'), start: 'top 80%' } }
        );
      }

      if (guaranteeRef.current) {
        gsap.fromTo(
          guaranteeRef.current.querySelectorAll('.guarantee-anim'),
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, stagger: 0.15, ease: 'power3.out', scrollTrigger: { trigger: guaranteeRef.current, start: 'top 75%' } }
        );
      }

      if (enterpriseRef.current) {
        gsap.fromTo(
          enterpriseRef.current.querySelector('.section-header'),
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, ease: 'power3.out', scrollTrigger: { trigger: enterpriseRef.current, start: 'top 75%' } }
        );
        gsap.fromTo(
          enterpriseRef.current.querySelectorAll('.benefit-card'),
          { y: 50, opacity: 0, scale: 0.95 },
          { y: 0, opacity: 1, scale: 1, duration: 0.6, stagger: 0.12, ease: 'power3.out', scrollTrigger: { trigger: enterpriseRef.current.querySelector('.benefit-grid'), start: 'top 80%' } }
        );
      }

      if (faqRef.current) {
        gsap.fromTo(
          faqRef.current.querySelector('.section-header'),
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, ease: 'power3.out', scrollTrigger: { trigger: faqRef.current, start: 'top 75%' } }
        );
      }
    });
    return () => ctx.revert();
  }, []);

  const renderCellValue = (value: string | boolean) => {
    if (value === false) {
      return <X className="w-5 h-5 text-gray-300 mx-auto" />;
    }
    if (value === 'check') {
      return <Check className="w-5 h-5 text-emerald-500 mx-auto" />;
    }
    return <span className="text-sm text-vare-slate font-medium">{value}</span>;
  };

  return (
    <>
      <Navigation />
      <PageDecorations />
      <main>
        {/* Hero */}
        <section ref={heroRef} className="relative pt-32 pb-24 overflow-hidden gradient-purple-dark">
          <div className="absolute inset-0">
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(123,77,187,0.3),transparent_50%)]" />
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,rgba(58,26,112,0.4),transparent_50%)]" />
            <div className="absolute top-20 left-10 w-72 h-72 bg-purple-500/10 rounded-full blur-3xl" />
            <div className="absolute bottom-20 right-10 w-96 h-96 bg-purple-400/10 rounded-full blur-3xl" />
          </div>
          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <span className="hero-anim inline-flex items-center px-3 py-1 rounded-full glass-effect text-white/90 text-sm font-medium mb-6 opacity-0">
              <Sparkles className="w-4 h-4 mr-1.5" /> Pricing
            </span>
            <h1 className="hero-anim text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-6 opacity-0">
              Simple, Transparent <span className="text-transparent bg-clip-text bg-gradient-to-r from-vare-gold to-yellow-300">Pricing</span>
            </h1>
            <p className="hero-anim max-w-2xl mx-auto text-lg text-white/70 leading-relaxed opacity-0">
              No hidden fees. No surprises. Choose the plan that fits your needs and budget. Every plan includes our commitment to quality.
            </p>
          </div>
        </section>

        {/* Pricing Cards */}
        <section ref={pricingRef} className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="section-header text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-vare-slate mb-4">
                Choose Your <span className="text-gradient">Plan</span>
              </h2>
              <p className="text-vare-gray max-w-2xl mx-auto text-lg">
                Every plan includes our commitment to quality and your success.
              </p>
            </div>
            <div className="pricing-grid grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              {pricingPlans.map((plan, i) => (
                <div
                  key={i}
                  className={`pricing-card relative bg-white rounded-2xl p-8 border-2 transition-all duration-500 hover:shadow-xl ${
                    plan.popular
                      ? 'border-vare-purple shadow-lg shadow-purple-500/10 scale-105'
                      : 'border-gray-100 hover:border-vare-purple/20'
                  }`}
                >
                  {plan.popular && (
                    <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 gradient-purple text-white text-xs font-medium rounded-full">
                      Most Popular
                    </div>
                  )}
                  <h3 className="text-xl font-bold text-vare-slate mb-2">{plan.name}</h3>
                  <p className="text-vare-gray text-sm mb-6">{plan.desc}</p>
                  <div className="mb-6">
                    <span className="text-4xl font-bold text-vare-slate">{plan.price}</span>
                    <span className="text-vare-gray">{plan.period}</span>
                  </div>
                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature, j) => (
                      <li key={j} className="flex items-center text-sm text-vare-slate">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 mr-2.5 flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Link
                    href="/contact"
                    className={`block w-full text-center py-3 rounded-xl font-medium transition-all duration-300 ${
                      plan.popular
                        ? 'gradient-purple text-white hover:shadow-lg hover:shadow-purple-500/25'
                        : 'bg-vare-ice text-vare-purple hover:bg-vare-purple hover:text-white'
                    }`}
                  >
                    Get Started
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Feature Comparison Table */}
        <section ref={comparisonRef} className="py-24 bg-white">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="section-header text-center mb-16">
              <span className="inline-flex items-center px-3 py-1 rounded-full bg-vare-ice text-vare-purple text-sm font-medium mb-4">
                Compare Plans
              </span>
              <h2 className="text-3xl md:text-4xl font-bold text-vare-slate mb-4">
                Detailed <span className="text-gradient">Feature Comparison</span>
              </h2>
              <p className="text-vare-gray max-w-2xl mx-auto text-lg">
                See exactly what&apos;s included in each plan to make the best choice for your business.
              </p>
            </div>

            {/* Desktop Table */}
            <div className="comparison-table hidden md:block bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm">
              <table className="w-full">
                <thead>
                  <tr className="gradient-purple text-white">
                    <th className="text-left py-4 px-6 font-semibold text-sm">Features</th>
                    <th className="text-center py-4 px-6 font-semibold text-sm">Starter</th>
                    <th className="text-center py-4 px-6 font-semibold text-sm">
                      <div>
                        Professional
                        <div className="text-xs font-normal text-white/80 mt-0.5">Most Popular</div>
                      </div>
                    </th>
                    <th className="text-center py-4 px-6 font-semibold text-sm">Enterprise</th>
                  </tr>
                </thead>
                <tbody>
                  {comparisonFeatures.map((row, i) => (
                    <tr
                      key={row.feature}
                      className={`comparison-row border-b border-gray-50 last:border-b-0 ${
                        i % 2 === 0 ? 'bg-white' : 'bg-vare-ice/50'
                      }`}
                    >
                      <td className="py-4 px-6 text-sm text-vare-slate font-medium">{row.feature}</td>
                      <td className="py-4 px-6 text-center">{renderCellValue(row.starter)}</td>
                      <td className="py-4 px-6 text-center bg-vare-purple/5">{renderCellValue(row.professional)}</td>
                      <td className="py-4 px-6 text-center">{renderCellValue(row.enterprise)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile Cards */}
            <div className="md:hidden space-y-6">
              {pricingPlans.map((plan) => (
                <div key={plan.name} className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm">
                  <div className={`${plan.popular ? 'gradient-purple' : 'bg-vare-slate'} px-5 py-4 text-white`}>
                    <h3 className="text-lg font-bold">{plan.name}</h3>
                    <p className="text-white/80 text-sm">{plan.price}{plan.period}</p>
                  </div>
                  <div className="divide-y divide-gray-50">
                    {comparisonFeatures.map((row) => {
                      const value = row.feature === 'Custom Pages' ? row.starter
                        : row.feature === 'Responsive Design' ? row.starter
                        : row.feature === 'SEO Optimization' ? row.starter
                        : row.feature === 'SSL Certificate' ? row.starter
                        : row.feature === 'CMS Integration' ? row.starter
                        : row.feature === 'Contact Forms' ? row.starter
                        : row.feature === 'Analytics' ? row.starter
                        : row.feature === 'Social Media Integration' ? row.starter
                        : row.feature === 'Email Support' ? row.starter
                        : row.feature === 'Phone Support' ? row.starter
                        : row.feature === 'Revision Rounds' ? row.starter
                        : row.feature === 'Delivery Time' ? row.starter
                        : row.starter;

                      const actualValue = plan.name === 'Starter' ? row.starter
                        : plan.name === 'Professional' ? row.professional
                        : row.enterprise;

                      return (
                        <div key={row.feature} className="flex items-center justify-between px-5 py-3">
                          <span className="text-sm text-vare-slate">{row.feature}</span>
                          <div className="flex-shrink-0 ml-3">
                            {renderCellValue(actualValue)}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Money-Back Guarantee */}
        <section ref={guaranteeRef} className="py-24 bg-vare-ice">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="guarantee-anim w-20 h-20 rounded-full gradient-purple flex items-center justify-center mx-auto mb-8">
              <ShieldCheck className="w-10 h-10 text-white" />
            </div>
            <h2 className="guarantee-anim text-3xl md:text-4xl font-bold text-vare-slate mb-6">
              100% Satisfaction <span className="text-gradient">Guarantee</span>
            </h2>
            <p className="guarantee-anim text-vare-gray text-lg leading-relaxed max-w-2xl mx-auto mb-12">
              We&apos;re so confident in our work that we offer a 30-day money-back guarantee. If you&apos;re not completely satisfied with the results, we&apos;ll refund your payment in full. No questions asked.
            </p>
            <div className="guarantee-anim grid grid-cols-1 sm:grid-cols-3 gap-6">
              <div className="bg-white rounded-xl p-6 border border-gray-100 shadow-sm">
                <div className="w-12 h-12 rounded-full bg-emerald-50 flex items-center justify-center mx-auto mb-3">
                  <ShieldCheck className="w-6 h-6 text-emerald-500" />
                </div>
                <h4 className="font-semibold text-vare-slate mb-1">30-Day Money Back</h4>
                <p className="text-vare-gray text-sm">Full refund if you&apos;re not satisfied</p>
              </div>
              <div className="bg-white rounded-xl p-6 border border-gray-100 shadow-sm">
                <div className="w-12 h-12 rounded-full bg-vare-purple/10 flex items-center justify-center mx-auto mb-3">
                  <CheckCircle2 className="w-6 h-6 text-vare-purple" />
                </div>
                <h4 className="font-semibold text-vare-slate mb-1">No Hidden Fees</h4>
                <p className="text-vare-gray text-sm">Transparent pricing from day one</p>
              </div>
              <div className="bg-white rounded-xl p-6 border border-gray-100 shadow-sm">
                <div className="w-12 h-12 rounded-full bg-amber-50 flex items-center justify-center mx-auto mb-3">
                  <Sparkles className="w-6 h-6 text-amber-500" />
                </div>
                <h4 className="font-semibold text-vare-slate mb-1">Free Revisions</h4>
                <p className="text-vare-gray text-sm">Included in every plan we offer</p>
              </div>
            </div>
          </div>
        </section>

        {/* Enterprise Custom Solutions */}
        <section ref={enterpriseRef} className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="section-header text-center mb-16">
              <span className="inline-flex items-center px-3 py-1 rounded-full bg-vare-ice text-vare-purple text-sm font-medium mb-4">
                Enterprise
              </span>
              <h2 className="text-3xl md:text-4xl font-bold text-vare-slate mb-4">
                Need a <span className="text-gradient">Custom Solution?</span>
              </h2>
              <p className="text-vare-gray max-w-2xl mx-auto text-lg">
                Our enterprise packages are fully tailored to your organization&apos;s unique requirements, scale, and long-term vision.
              </p>
            </div>
            <div className="benefit-grid grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto">
              {enterpriseBenefits.map((benefit) => (
                <div
                  key={benefit.title}
                  className="benefit-card group bg-white rounded-2xl p-6 border border-gray-100 hover:border-vare-purple/20 hover:shadow-xl transition-all duration-300 text-center"
                >
                  <div className="w-14 h-14 rounded-xl gradient-purple flex items-center justify-center mx-auto mb-5 group-hover:scale-110 transition-transform duration-300">
                    <benefit.icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-lg font-bold text-vare-slate mb-2">{benefit.title}</h3>
                  <p className="text-vare-gray text-sm leading-relaxed">{benefit.description}</p>
                </div>
              ))}
            </div>
            <div className="text-center mt-12">
              <Link
                href="/contact"
                className="inline-flex items-center px-8 py-4 text-base font-medium text-white gradient-purple rounded-xl hover:shadow-lg hover:shadow-purple-500/25 transform hover:-translate-y-0.5 transition-all duration-300"
              >
                Contact Sales <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section ref={faqRef} className="py-24 bg-vare-ice">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="section-header text-center mb-16">
              <span className="inline-flex items-center px-3 py-1 rounded-full bg-white text-vare-purple text-sm font-medium mb-4">
                FAQ
              </span>
              <h2 className="text-3xl md:text-4xl font-bold text-vare-slate mb-4">
                Frequently Asked <span className="text-gradient">Questions</span>
              </h2>
              <p className="text-vare-gray text-lg">
                Everything you need to know about our services and pricing.
              </p>
            </div>
            <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
              <Accordion type="single" collapsible className="w-full">
                {faqs.map((faq, i) => (
                  <AccordionItem key={i} value={`item-${i}`} className="px-6 border-b border-gray-100 last:border-b-0">
                    <AccordionTrigger className="text-left text-vare-slate font-medium hover:text-vare-purple hover:no-underline py-5">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-vare-gray text-sm leading-relaxed pb-5">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-24 bg-vare-ice relative overflow-hidden">
          <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="bg-white rounded-3xl p-10 sm:p-14 shadow-xl shadow-vare-purple/5 border border-gray-100 relative overflow-hidden">
              <div className="absolute top-0 left-0 right-0 h-1 gradient-purple" />
              <div className="relative">
                <div className="w-16 h-16 rounded-2xl gradient-purple flex items-center justify-center mx-auto mb-6">
                  <Sparkles className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-3xl md:text-4xl font-bold text-vare-slate mb-4">
                  Need a Custom Solution?
                </h2>
                <p className="text-vare-gray text-base sm:text-lg mb-8 max-w-xl mx-auto leading-relaxed">
                  Every business is unique. If our standard plans don&apos;t match your exact needs, let us build a custom package with the features and support level that&apos;s right for you.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                  <Link
                    href="/contact"
                    className="inline-flex items-center px-8 py-4 text-base font-semibold text-white gradient-purple rounded-xl hover:shadow-lg hover:shadow-purple-500/25 transform hover:-translate-y-1 transition-all duration-300"
                  >
                    Request Custom Quote <ArrowRight className="ml-2 w-5 h-5" />
                  </Link>
                  <a
                    href="tel:+16592006383"
                    className="inline-flex items-center px-8 py-4 text-base font-medium text-vare-purple border-2 border-vare-purple/20 rounded-xl hover:bg-vare-purple/5 transition-all duration-300"
                  >
                    <Phone className="mr-2 w-5 h-5" />
                    Call Us Directly
                  </a>
                </div>
                <p className="mt-8 text-vare-gray text-sm">
                  Prefer email? Reach us at{' '}
                  <a href="mailto:contact@vareweb.com" className="text-vare-purple font-medium hover:underline">contact@vareweb.com</a>
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
