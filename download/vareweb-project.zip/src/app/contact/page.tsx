'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import Link from 'next/link';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import PageDecorations from '@/components/PageDecorations';
import {
  Mail, Phone, MapPin, Send, CheckCircle2,
  MessageCircle, Clock, ArrowRight, Calendar,
  ChevronLeft, ChevronRight,
  Facebook, Twitter, Linkedin, Instagram,
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const contactInfo = [
  { icon: Mail, label: 'Email Us', value: 'contact@vareweb.com', href: 'mailto:contact@vareweb.com', desc: 'We respond within 24 hours' },
  { icon: Phone, label: 'Call Us', value: '+1 659 200 6383', href: 'tel:+16592006383', desc: 'Mon-Fri 9am-6pm CST' },
  { icon: MapPin, label: 'Visit Us', value: '5400 Preston Oaks Rd, Dallas, TX 75254, USA', href: '#', desc: 'By appointment only' },
];

const socialMedia = [
  {
    icon: Facebook,
    name: 'Facebook',
    description: 'Follow us for updates',
    followers: '15K+ Followers',
    color: 'from-blue-600 to-blue-700',
    hoverShadow: 'hover:shadow-blue-500/25',
  },
  {
    icon: Twitter,
    name: 'Twitter / X',
    description: 'Latest news & tips',
    followers: '8K+ Followers',
    color: 'from-gray-800 to-gray-900',
    hoverShadow: 'hover:shadow-gray-500/25',
  },
  {
    icon: Linkedin,
    name: 'LinkedIn',
    description: 'Professional network',
    followers: '12K+ Connections',
    color: 'from-blue-700 to-blue-800',
    hoverShadow: 'hover:shadow-blue-600/25',
  },
  {
    icon: Instagram,
    name: 'Instagram',
    description: 'Behind the scenes',
    followers: '20K+ Followers',
    color: 'from-pink-500 via-purple-500 to-orange-400',
    hoverShadow: 'hover:shadow-pink-500/25',
  },
];

export default function ContactPage() {
  const heroRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLElement>(null);
  const calendarRef = useRef<HTMLElement>(null);
  const mapRef = useRef<HTMLElement>(null);
  const socialRef = useRef<HTMLElement>(null);
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  // Calendar state
  const today = new Date();
  const [currentMonth, setCurrentMonth] = useState(today.getMonth());
  const [currentYear, setCurrentYear] = useState(today.getFullYear());
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [booking, setBooking] = useState(false);
  const [bookingSuccess, setBookingSuccess] = useState(false);
  const [formData, setFormData] = useState({ fullName: '', email: '', phone: '', serviceType: 'Web Design', message: '' });

  const timeSlots = ['9:00 AM', '10:00 AM', '11:00 AM', '1:00 PM', '2:00 PM', '3:00 PM', '4:00 PM', '5:00 PM'];
  const serviceOptions = ['Web Design', 'Logo Design', 'Digital Marketing', 'SEO Optimization', 'eCommerce', 'Custom Software', 'Mobile App Development', 'GHL Development & Automation'];

  const getDaysInMonth = (month: number, year: number) => new Date(year, month + 1, 0).getDate();
  const getFirstDayOfMonth = (month: number, year: number) => new Date(year, month, 1).getDay();
  const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  const formatDateStr = (day: number) => {
    return `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  };

  const isPastDay = (day: number) => {
    const date = new Date(currentYear, currentMonth, day);
    const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    return date < todayStart;
  };

  const isToday = (day: number) => {
    return currentYear === today.getFullYear() && currentMonth === today.getMonth() && day === today.getDate();
  };

  const prevMonth = () => {
    if (currentMonth === 0) { setCurrentMonth(11); setCurrentYear(currentYear - 1); }
    else setCurrentMonth(currentMonth - 1);
  };

  const nextMonth = () => {
    if (currentMonth === 11) { setCurrentMonth(0); setCurrentYear(currentYear + 1); }
    else setCurrentMonth(currentMonth + 1);
  };

  const handleBookingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDate || !selectedTime) return;
    setBooking(true);
    try {
      const res = await fetch('/api/appointments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fullName: formData.fullName,
          email: formData.email,
          phone: formData.phone,
          serviceType: formData.serviceType,
          preferredDate: selectedDate,
          preferredTime: selectedTime,
          message: formData.message || null,
        }),
      });
      if (res.ok) {
        setBookingSuccess(true);
      } else {
        alert('Failed to book appointment. Please try again.');
      }
    } catch {
      alert('Something went wrong. Please try again.');
    } finally {
      setBooking(false);
    }
  };

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (heroRef.current) {
        gsap.fromTo(
          heroRef.current.querySelectorAll('.hero-anim'),
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, stagger: 0.15, ease: 'power3.out' }
        );
      }

      if (contentRef.current) {
        gsap.fromTo(
          contentRef.current.querySelectorAll('.contact-detail'),
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.5, stagger: 0.1, ease: 'power3.out', scrollTrigger: { trigger: contentRef.current, start: 'top 75%' } }
        );
        gsap.fromTo(
          contentRef.current.querySelector('.contact-form'),
          { y: 30, opacity: 0, scale: 0.98 },
          { y: 0, opacity: 1, scale: 1, duration: 0.7, ease: 'power3.out', scrollTrigger: { trigger: contentRef.current, start: 'top 75%' } }
        );
      }

      if (calendarRef.current) {
        gsap.fromTo(
          calendarRef.current.querySelectorAll('.cal-anim'),
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, stagger: 0.15, ease: 'power3.out', scrollTrigger: { trigger: calendarRef.current, start: 'top 75%' } }
        );
      }

      if (mapRef.current) {
        gsap.fromTo(
          mapRef.current.querySelectorAll('.map-anim'),
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, stagger: 0.15, ease: 'power3.out', scrollTrigger: { trigger: mapRef.current, start: 'top 75%' } }
        );
      }

      if (socialRef.current) {
        gsap.fromTo(
          socialRef.current.querySelector('.section-header'),
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, ease: 'power3.out', scrollTrigger: { trigger: socialRef.current, start: 'top 75%' } }
        );
        gsap.fromTo(
          socialRef.current.querySelectorAll('.social-card'),
          { y: 50, opacity: 0, scale: 0.95 },
          { y: 0, opacity: 1, scale: 1, duration: 0.6, stagger: 0.12, ease: 'power3.out', scrollTrigger: { trigger: socialRef.current.querySelector('.social-grid'), start: 'top 80%' } }
        );
      }
    });
    return () => ctx.revert();
  }, []);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    setSending(true);
    const formData = new FormData(e.target as HTMLFormElement);
    const data = {
      name: formData.get('name'),
      email: formData.get('email'),
      phone: formData.get('phone'),
      serviceType: formData.get('service'),
      message: formData.get('message'),
    };
    try {
      await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      setSent(true);
      (e.target as HTMLFormElement).reset();
    } catch {
      alert('Something went wrong. Please try again.');
    } finally {
      setSending(false);
    }
  }, []);

  return (
    <>
      <Navigation />
      <PageDecorations />
      <main>
        {/* Hero */}
        <section ref={heroRef} className="relative pt-32 pb-24 overflow-hidden gradient-purple-dark">
          <div className="absolute inset-0">
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(123,77,187,0.3),transparent_50%)]" />
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,rgba(58,26,112,0.4),transparent_50%)]" />
            <div className="absolute top-20 left-10 w-72 h-72 bg-purple-500/10 rounded-full blur-3xl" />
            <div className="absolute bottom-20 right-10 w-96 h-96 bg-purple-400/10 rounded-full blur-3xl" />
          </div>
          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <span className="hero-anim inline-flex items-center px-3 py-1 rounded-full glass-effect text-white/90 text-sm font-medium mb-6 opacity-0">
              <MessageCircle className="w-4 h-4 mr-1.5" /> Get In Touch
            </span>
            <h1 className="hero-anim text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-6 opacity-0">
              Let&apos;s <span className="text-transparent bg-clip-text bg-gradient-to-r from-vare-gold to-yellow-300">Talk</span>
            </h1>
            <p className="hero-anim max-w-2xl mx-auto text-lg text-white/70 leading-relaxed opacity-0">
              Have a project in mind? We would love to hear about it. Reach out and let&apos;s discuss how we can help bring your vision to life.
            </p>
          </div>
        </section>

        {/* Contact Content */}
        <section ref={contentRef} className="py-24 bg-vare-ice">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Contact Info Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
              {contactInfo.map((item, i) => (
                <a
                  key={i}
                  href={item.href}
                  className="contact-detail group bg-white rounded-2xl p-8 border border-gray-100 hover:border-vare-purple/20 hover:shadow-lg transition-all duration-300 text-center"
                >
                  <div className="w-14 h-14 rounded-xl gradient-purple flex items-center justify-center mx-auto mb-4 transform group-hover:scale-110 transition-transform duration-300">
                    <item.icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-lg font-bold text-vare-slate mb-1">{item.label}</h3>
                  <p className="text-vare-purple font-medium text-sm mb-1">{item.value}</p>
                  <p className="text-vare-gray text-xs">{item.desc}</p>
                </a>
              ))}
            </div>

            {/* Contact Form */}
            <div className="contact-form max-w-3xl mx-auto bg-white rounded-2xl p-8 md:p-10 border border-gray-100 shadow-sm">
              <div className="text-center mb-8">
                <h2 className="text-2xl md:text-3xl font-bold text-vare-slate mb-3">
                  Send Us a Message
                </h2>
                <p className="text-vare-gray">
                  Fill out the form below and we&apos;ll get back to you within 24 hours.
                </p>
              </div>

              {sent ? (
                <div className="text-center py-12">
                  <CheckCircle2 className="w-16 h-16 text-emerald-500 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-vare-slate mb-2">Message Sent!</h3>
                  <p className="text-vare-gray mb-6">Thank you for reaching out. We&apos;ll get back to you within 24 hours.</p>
                  <button onClick={() => setSent(false)} className="text-vare-purple font-medium hover:underline">
                    Send Another Message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-sm font-medium text-vare-slate mb-1.5">Name *</label>
                      <input
                        name="name"
                        required
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-vare-purple/20 focus:border-vare-purple transition-all"
                        placeholder="Your name"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-vare-slate mb-1.5">Email *</label>
                      <input
                        name="email"
                        type="email"
                        required
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-vare-purple/20 focus:border-vare-purple transition-all"
                        placeholder="your@email.com"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-sm font-medium text-vare-slate mb-1.5">Phone *</label>
                      <input
                        name="phone"
                        required
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-vare-purple/20 focus:border-vare-purple transition-all"
                        placeholder="+1 (555) 000-0000"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-vare-slate mb-1.5">Service</label>
                      <select
                        name="service"
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-vare-purple/20 focus:border-vare-purple transition-all bg-white"
                      >
                        <option>Web Design</option>
                        <option>Logo Design</option>
                        <option>Digital Marketing</option>
                        <option>SEO Optimization</option>
                        <option>eCommerce</option>
                        <option>Custom Software</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-vare-slate mb-1.5">Message</label>
                    <textarea
                      name="message"
                      rows={5}
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-vare-purple/20 focus:border-vare-purple transition-all resize-none"
                      placeholder="Tell us about your project..."
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={sending}
                    className="w-full py-3.5 gradient-purple text-white rounded-xl font-medium hover:shadow-lg hover:shadow-purple-500/25 transform hover:-translate-y-0.5 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                  >
                    {sending ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        <span>Sending...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>Send Message</span>
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>
          </div>
        </section>

        {/* Calendar Booking Section */}
        <section ref={calendarRef} className="py-24 bg-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="cal-anim text-center mb-12">
              <span className="inline-flex items-center px-3 py-1 rounded-full bg-vare-ice text-vare-purple text-sm font-medium mb-4">
                <Calendar className="w-4 h-4 mr-1.5" /> Book a Session
              </span>
              <h2 className="text-3xl md:text-4xl font-bold text-vare-slate mb-4">
                Schedule a <span className="text-gradient">Consultation</span>
              </h2>
              <p className="text-vare-gray max-w-2xl mx-auto text-lg">
                Pick a date and time that works for you, and we&apos;ll set up a free consultation to discuss your project needs.
              </p>
            </div>

            {bookingSuccess ? (
              <div className="cal-anim text-center py-16 bg-vare-ice rounded-2xl border border-gray-100">
                <div className="w-20 h-20 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-6">
                  <CheckCircle2 className="w-10 h-10 text-emerald-500" />
                </div>
                <h3 className="text-2xl font-bold text-vare-slate mb-2">Appointment Booked!</h3>
                <p className="text-vare-gray mb-1">We&apos;ve received your consultation request.</p>
                <p className="text-vare-purple font-medium mb-6">
                  {selectedDate} at {selectedTime}
                </p>
                <p className="text-vare-gray text-sm mb-8">
                  A confirmation will be sent to <span className="font-medium text-vare-slate">{formData.email}</span>
                </p>
                <button
                  onClick={() => {
                    setBookingSuccess(false);
                    setSelectedDate(null);
                    setSelectedTime(null);
                    setFormData({ fullName: '', email: '', phone: '', serviceType: 'Web Design', message: '' });
                  }}
                  className="px-6 py-3 gradient-purple text-white rounded-xl font-medium hover:shadow-lg hover:shadow-purple-500/25 transform hover:-translate-y-0.5 transition-all duration-300"
                >
                  Book Another Appointment
                </button>
              </div>
            ) : (
              <div className="space-y-8">
                {/* Calendar Card */}
                <div className="cal-anim bg-white rounded-2xl p-6 md:p-8 border border-gray-100 shadow-sm">
                  {/* Month Navigation */}
                  <div className="flex items-center justify-between mb-6">
                    <button onClick={prevMonth} className="p-2 rounded-xl hover:bg-vare-ice transition-colors text-vare-slate">
                      <ChevronLeft className="w-5 h-5" />
                    </button>
                    <h3 className="text-lg font-bold text-vare-slate">{monthNames[currentMonth]} {currentYear}</h3>
                    <button onClick={nextMonth} className="p-2 rounded-xl hover:bg-vare-ice transition-colors text-vare-slate">
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </div>

                  {/* Day headers */}
                  <div className="grid grid-cols-7 gap-1 mb-2">
                    {dayNames.map((day) => (
                      <div key={day} className="text-center text-xs font-semibold text-vare-gray py-2">{day}</div>
                    ))}
                  </div>

                  {/* Day grid */}
                  <div className="grid grid-cols-7 gap-1">
                    {Array.from({ length: getFirstDayOfMonth(currentMonth, currentYear) }).map((_, i) => (
                      <div key={`empty-${i}`} />
                    ))}
                    {Array.from({ length: getDaysInMonth(currentMonth, currentYear) }).map((_, i) => {
                      const day = i + 1;
                      const dateStr = formatDateStr(day);
                      const past = isPastDay(day);
                      const selected = selectedDate === dateStr;
                      const todayFlag = isToday(day);

                      return (
                        <button
                          key={day}
                          disabled={past}
                          onClick={() => { setSelectedDate(dateStr); setSelectedTime(null); }}
                          className={`relative w-full aspect-square flex items-center justify-center rounded-xl text-sm font-medium transition-all duration-200 ${
                            past
                              ? 'text-gray-300 cursor-not-allowed'
                              : selected
                              ? 'bg-vare-purple text-white shadow-lg shadow-purple-500/30'
                              : todayFlag
                              ? 'text-vare-purple ring-2 ring-vare-purple/30 hover:bg-vare-purple/10'
                              : 'text-vare-slate hover:bg-vare-ice'
                          }`}
                        >
                          {day}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Time Slots Card */}
                <div className="cal-anim bg-white rounded-2xl p-6 md:p-8 border border-gray-100 shadow-sm">
                  <h3 className="text-base font-bold text-vare-slate mb-4">Select a Time Slot</h3>
                  <div className="grid grid-cols-4 sm:grid-cols-8 gap-3">
                    {timeSlots.map((time) => (
                      <button
                        key={time}
                        disabled={!selectedDate}
                        onClick={() => setSelectedTime(time)}
                        className={`py-2.5 px-2 rounded-xl text-xs sm:text-sm font-medium transition-all duration-200 ${
                          !selectedDate
                            ? 'bg-gray-100 text-gray-300 cursor-not-allowed'
                            : selectedTime === time
                            ? 'bg-vare-purple text-white shadow-md shadow-purple-500/25'
                            : 'bg-vare-ice text-vare-slate hover:bg-vare-purple/10 hover:text-vare-purple'
                        }`}
                      >
                        {time}
                      </button>
                    ))}
                  </div>
                  {!selectedDate && (
                    <p className="text-xs text-vare-gray mt-3">Please select a date first</p>
                  )}
                </div>

                {/* Booking Form Card */}
                <div className="cal-anim bg-white rounded-2xl p-6 md:p-8 border border-gray-100 shadow-sm">
                  <h3 className="text-base font-bold text-vare-slate mb-6">Your Details</h3>
                  <form onSubmit={handleBookingSubmit} className="space-y-5">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div>
                        <label className="block text-sm font-medium text-vare-slate mb-1.5">Full Name *</label>
                        <input
                          required
                          value={formData.fullName}
                          onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                          className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-vare-purple/20 focus:border-vare-purple transition-all"
                          placeholder="Your name"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-vare-slate mb-1.5">Email *</label>
                        <input
                          type="email"
                          required
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-vare-purple/20 focus:border-vare-purple transition-all"
                          placeholder="your@email.com"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div>
                        <label className="block text-sm font-medium text-vare-slate mb-1.5">Phone *</label>
                        <input
                          required
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-vare-purple/20 focus:border-vare-purple transition-all"
                          placeholder="+1 (555) 000-0000"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-vare-slate mb-1.5">Service Type *</label>
                        <select
                          value={formData.serviceType}
                          onChange={(e) => setFormData({ ...formData, serviceType: e.target.value })}
                          className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-vare-purple/20 focus:border-vare-purple transition-all bg-white"
                        >
                          {serviceOptions.map((s) => <option key={s} value={s}>{s}</option>)}
                        </select>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-vare-slate mb-1.5">Message (optional)</label>
                      <textarea
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        rows={3}
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-vare-purple/20 focus:border-vare-purple transition-all resize-none"
                        placeholder="Briefly describe your project..."
                      />
                    </div>

                    {/* Selected summary */}
                    {(selectedDate || selectedTime) && (
                      <div className="flex flex-wrap items-center gap-2 text-sm">
                        {selectedDate && (
                          <span className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-vare-purple/10 text-vare-purple font-medium">
                            <Calendar className="w-3.5 h-3.5" /> {selectedDate}
                          </span>
                        )}
                        {selectedTime && (
                          <span className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-vare-purple/10 text-vare-purple font-medium">
                            <Clock className="w-3.5 h-3.5" /> {selectedTime}
                          </span>
                        )}
                      </div>
                    )}

                    <button
                      type="submit"
                      disabled={booking || !selectedDate || !selectedTime}
                      className="w-full py-3.5 gradient-purple text-white rounded-xl font-medium hover:shadow-lg hover:shadow-purple-500/25 transform hover:-translate-y-0.5 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                    >
                      {booking ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                          <span>Booking...</span>
                        </>
                      ) : (
                        <>
                          <Calendar className="w-4 h-4" />
                          <span>Book Appointment</span>
                        </>
                      )}
                    </button>
                    {!selectedDate || !selectedTime ? (
                      <p className="text-xs text-center text-vare-gray">Please select both a date and time to book</p>
                    ) : null}
                  </form>
                </div>
              </div>
            )}
          </div>
        </section>

        {/* Map / Office Location */}
        <section ref={mapRef} className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="map-anim text-center mb-12">
              <span className="inline-flex items-center px-3 py-1 rounded-full bg-vare-ice text-vare-purple text-sm font-medium mb-4">
                Our Location
              </span>
              <h2 className="text-3xl md:text-4xl font-bold text-vare-slate mb-4">
                Visit Our <span className="text-gradient">Office</span>
              </h2>
              <p className="text-vare-gray max-w-2xl mx-auto text-lg">
                Come meet us in person. We&apos;d love to discuss your project over a cup of coffee.
              </p>
            </div>
            <div className="map-anim grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-5xl mx-auto">
              {/* Map Placeholder */}
              <div className="relative rounded-2xl overflow-hidden aspect-[4/3] lg:aspect-auto">
                <div className="absolute inset-0 bg-gradient-to-br from-vare-purple/20 via-vare-ice to-vare-purple/10" />
                <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg width=\'60\' height=\'60\' viewBox=\'0 0 60 60\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cg fill=\'none\' fill-rule=\'evenodd\'%3E%3Cg fill=\'%233a1a70\' fill-opacity=\'0.15\'%3E%3Cpath d=\'M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z\'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")' }} />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-20 h-20 rounded-full gradient-purple flex items-center justify-center mx-auto mb-4 shadow-xl shadow-purple-500/25 animate-bounce" style={{ animationDuration: '2s' }}>
                      <MapPin className="w-10 h-10 text-white" />
                    </div>
                    <div className="bg-white/90 backdrop-blur-sm rounded-xl px-5 py-3 shadow-lg">
                      <p className="text-vare-slate font-semibold text-sm">5400 Preston Oaks Rd</p>
                      <p className="text-vare-gray text-xs">Dallas, TX 75254, USA</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Office Details */}
              <div className="flex flex-col justify-center space-y-6">
                <div className="map-anim flex items-start gap-4 p-5 bg-vare-ice rounded-xl">
                  <div className="w-12 h-12 rounded-xl gradient-purple flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-vare-slate mb-1">Address</h4>
                    <p className="text-vare-gray text-sm leading-relaxed">5400 Preston Oaks Rd, Dallas, TX 75254, USA</p>
                  </div>
                </div>
                <div className="map-anim flex items-start gap-4 p-5 bg-vare-ice rounded-xl">
                  <div className="w-12 h-12 rounded-xl gradient-purple flex items-center justify-center flex-shrink-0">
                    <Clock className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-vare-slate mb-1">Office Hours</h4>
                    <div className="text-vare-gray text-sm space-y-1">
                      <p>Monday - Friday: 9:00 AM - 6:00 PM CST</p>
                      <p>Saturday: 10:00 AM - 2:00 PM CST</p>
                      <p>Sunday: Closed</p>
                    </div>
                  </div>
                </div>
                <div className="map-anim flex items-start gap-4 p-5 bg-vare-ice rounded-xl">
                  <div className="w-12 h-12 rounded-xl gradient-purple flex items-center justify-center flex-shrink-0">
                    <Phone className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-vare-slate mb-1">Phone</h4>
                    <p className="text-vare-gray text-sm">+1 659 200 6383</p>
                    <p className="text-vare-gray text-xs mt-0.5">Available during office hours</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Social Media & Quick Contact */}
        <section ref={socialRef} className="py-24 bg-vare-ice">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="section-header text-center mb-16">
              <span className="inline-flex items-center px-3 py-1 rounded-full bg-white text-vare-purple text-sm font-medium mb-4">
                Social Media
              </span>
              <h2 className="text-3xl md:text-4xl font-bold text-vare-slate mb-4">
                Connect <span className="text-gradient">With Us</span>
              </h2>
              <p className="text-vare-gray max-w-2xl mx-auto text-lg">
                Follow us on social media to stay in the loop with our latest work, tips, and company updates.
              </p>
            </div>
            <div className="social-grid grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto">
              {socialMedia.map((social) => (
                <div
                  key={social.name}
                  className={`social-card group relative rounded-2xl overflow-hidden cursor-pointer transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl ${social.hoverShadow}`}
                >
                  <div className={`absolute inset-0 bg-gradient-to-br ${social.color} transition-transform duration-500 group-hover:scale-105`} />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-all duration-300" />
                  <div className="relative z-10 p-8 text-center">
                    <div className="w-16 h-16 rounded-2xl bg-white/15 backdrop-blur-sm flex items-center justify-center mx-auto mb-5 border border-white/20 group-hover:scale-110 group-hover:bg-white/25 transition-all duration-300">
                      <social.icon className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">{social.name}</h3>
                    <p className="text-white/70 text-sm mb-4">{social.description}</p>
                    <div className="inline-flex items-center px-4 py-1.5 rounded-full bg-white/15 backdrop-blur-sm text-white text-sm font-medium border border-white/20">
                      {social.followers}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA - What Happens Next */}
        <section className="py-20 bg-vare-ice relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 gradient-purple" />
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-vare-slate mb-4">
              What Happens <span className="text-gradient">Next?</span>
            </h2>
            <p className="text-vare-gray text-lg mb-8 max-w-2xl mx-auto">
              After you submit the form, our team reviews your project within 24 hours and schedules a free consultation call to discuss your goals in detail.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-3xl mx-auto mb-10">
              <div className="bg-white rounded-2xl p-6 border border-gray-100 hover:border-vare-purple/20 hover:shadow-lg transition-all duration-300">
                <div className="w-12 h-12 rounded-xl bg-vare-purple/10 flex items-center justify-center mx-auto mb-4">
                  <Send className="w-6 h-6 text-vare-purple" />
                </div>
                <h3 className="font-bold text-vare-slate mb-1">1. Submit Form</h3>
                <p className="text-vare-gray text-sm">Fill out the form above with your project details</p>
              </div>
              <div className="bg-white rounded-2xl p-6 border border-gray-100 hover:border-vare-purple/20 hover:shadow-lg transition-all duration-300">
                <div className="w-12 h-12 rounded-xl bg-vare-purple/10 flex items-center justify-center mx-auto mb-4">
                  <MessageCircle className="w-6 h-6 text-vare-purple" />
                </div>
                <h3 className="font-bold text-vare-slate mb-1">2. Free Consultation</h3>
                <p className="text-vare-gray text-sm">We schedule a call to understand your vision</p>
              </div>
              <div className="bg-white rounded-2xl p-6 border border-gray-100 hover:border-vare-purple/20 hover:shadow-lg transition-all duration-300">
                <div className="w-12 h-12 rounded-xl bg-vare-purple/10 flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-6 h-6 text-vare-purple" />
                </div>
                <h3 className="font-bold text-vare-slate mb-1">3. Get Started</h3>
                <p className="text-vare-gray text-sm">Receive a custom proposal and timeline</p>
              </div>
            </div>
            <p className="text-vare-gray text-sm">Prefer to talk now? <a href="tel:+16592006383" className="text-vare-purple font-medium hover:underline">Call us at +1 659 200 6383</a></p>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
