'use client';

import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import PageDecorations from '@/components/PageDecorations';
import { ArrowRight, FileText, Calendar, User, Mail, Send } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface BlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  category: string;
  tags: string;
  featuredImage: string;
  authorName: string;
  publishedAt: string;
  createdAt: string;
  status: string;
}

export default function BlogListingPage() {
  const heroRef = useRef<HTMLElement>(null);
  const featuredRef = useRef<HTMLElement>(null);
  const gridRef = useRef<HTMLElement>(null);
  const newsletterRef = useRef<HTMLElement>(null);
  const [blogs, setBlogs] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [subscribing, setSubscribing] = useState(false);

  useEffect(() => {
    fetch('/api/blogs?status=PUBLISHED&limit=100')
      .then((r) => r.json())
      .then((data) => {
        setBlogs(data.data || data.posts || []);
      })
      .catch(() => {
        setBlogs([]);
      })
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (heroRef.current) {
        gsap.fromTo(
          heroRef.current.querySelectorAll('.hero-anim'),
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, stagger: 0.15, ease: 'power3.out' }
        );
      }

      if (featuredRef.current) {
        gsap.fromTo(
          featuredRef.current.querySelectorAll('.featured-anim'),
          { y: 50, opacity: 0, scale: 0.97 },
          { y: 0, opacity: 1, scale: 1, duration: 0.8, stagger: 0.12, ease: 'power3.out', scrollTrigger: { trigger: featuredRef.current, start: 'top 75%' } }
        );
      }

      if (gridRef.current && !loading) {
        gsap.fromTo(
          gridRef.current.querySelectorAll('.blog-card'),
          { y: 50, opacity: 0, scale: 0.96 },
          { y: 0, opacity: 1, scale: 1, duration: 0.5, stagger: 0.1, ease: 'power3.out', scrollTrigger: { trigger: gridRef.current.querySelector('.blog-grid'), start: 'top 80%' } }
        );
      }

      if (newsletterRef.current) {
        gsap.fromTo(
          newsletterRef.current.querySelectorAll('.newsletter-anim'),
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, stagger: 0.15, ease: 'power3.out', scrollTrigger: { trigger: newsletterRef.current, start: 'top 75%' } }
        );
      }
    });
    return () => ctx.revert();
  }, [loading]);

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  };

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setSubscribing(true);
    setTimeout(() => {
      setSubscribed(true);
      setSubscribing(false);
    }, 1000);
  };

  return (
    <>
      <Navigation />
      <PageDecorations />
      <main>
        {/* Hero */}
        <section ref={heroRef} className="relative pt-32 pb-24 overflow-hidden gradient-purple-dark">
          <div className="absolute inset-0">
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(123,77,187,0.3),transparent_50%)]" />
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,rgba(58,26,112,0.4),transparent_50%)]" />
            <div className="absolute top-20 left-10 w-72 h-72 bg-purple-500/10 rounded-full blur-3xl" />
            <div className="absolute bottom-20 right-10 w-96 h-96 bg-purple-400/10 rounded-full blur-3xl" />
          </div>
          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <span className="hero-anim inline-flex items-center px-3 py-1 rounded-full glass-effect text-white/90 text-sm font-medium mb-6 opacity-0">
              <FileText className="w-4 h-4 mr-1.5" /> Our Blog
            </span>
            <h1 className="hero-anim text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-6 opacity-0">
              Latest <span className="text-transparent bg-clip-text bg-gradient-to-r from-vare-gold to-yellow-300">Insights</span>
            </h1>
            <p className="hero-anim max-w-2xl mx-auto text-lg text-white/70 leading-relaxed opacity-0">
              Stay updated with the latest trends, tips, and insights in web design, development, and digital marketing.
            </p>
          </div>
        </section>

        {/* Featured Post Hero */}
        <section ref={featuredRef} className="py-12 md:py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="featured-anim relative rounded-3xl overflow-hidden shadow-2xl">
              <div className="absolute inset-0 bg-gradient-to-br from-vare-purple via-vare-purple-light to-purple-800" />
              <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 20% 80%, rgba(255,255,255,0.3) 0%, transparent 50%), radial-gradient(circle at 80% 20%, rgba(245,158,11,0.2) 0%, transparent 50%)' }} />
              <div className="absolute top-6 right-6 w-64 h-64 bg-white/5 rounded-full blur-3xl" />
              <div className="absolute bottom-6 left-6 w-48 h-48 bg-vare-gold/10 rounded-full blur-3xl" />
              <div className="relative z-10 p-8 sm:p-12 md:p-16">
                <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-8">
                  <div className="flex-1">
                    <span className="featured-anim inline-flex items-center px-4 py-1.5 rounded-full bg-white/15 backdrop-blur-sm text-white text-sm font-medium mb-6 border border-white/20">
                      <Star className="w-3.5 h-3.5 mr-1.5 text-vare-gold" /> Featured Post
                    </span>
                    <h2 className="featured-anim text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-5 leading-tight">
                      The Future of Web Design: Trends to Watch in 2026
                    </h2>
                    <p className="featured-anim text-white/75 text-base sm:text-lg leading-relaxed max-w-2xl mb-8">
                      Explore the cutting-edge trends shaping the next era of web design — from AI-powered interfaces and immersive 3D experiences to hyper-personalization and sustainable design practices that are redefining user expectations.
                    </p>
                    <div className="featured-anim flex flex-wrap items-center gap-4 mb-8">
                      <span className="flex items-center gap-1.5 text-white/70 text-sm">
                        <User className="w-4 h-4" /> VareWeb Team
                      </span>
                      <span className="w-1 h-1 rounded-full bg-white/40" />
                      <span className="flex items-center gap-1.5 text-white/70 text-sm">
                        <Calendar className="w-4 h-4" /> January 15, 2026
                      </span>
                    </div>
                    <Link
                      href="/blog"
                      className="featured-anim inline-flex items-center px-6 py-3 bg-white text-vare-purple font-semibold rounded-xl hover:shadow-lg hover:shadow-white/25 transform hover:-translate-y-0.5 transition-all duration-300"
                    >
                      Read More <ArrowRight className="ml-2 w-4 h-4" />
                    </Link>
                  </div>
                  <div className="hidden lg:flex items-center justify-center w-48 h-48 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/10 flex-shrink-0">
                    <FileText className="w-20 h-20 text-white/20" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Blog Grid */}
        <section ref={gridRef} className="py-24 bg-vare-ice">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <div key={i} className="animate-pulse">
                    <div className="aspect-[16/10] rounded-2xl bg-gray-200 mb-6" />
                    <div className="h-5 bg-gray-200 rounded w-24 mb-3" />
                    <div className="h-6 bg-gray-200 rounded w-full mb-2" />
                    <div className="h-4 bg-gray-200 rounded w-full mb-1" />
                    <div className="h-4 bg-gray-200 rounded w-3/4" />
                  </div>
                ))}
              </div>
            ) : blogs.length === 0 ? (
              <div className="text-center py-20">
                <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-vare-slate mb-2">No Posts Yet</h3>
                <p className="text-vare-gray text-lg mb-8">Check back soon! We are working on some great articles for you.</p>
                <Link
                  href="/"
                  className="inline-flex items-center text-vare-purple font-medium hover:underline"
                >
                  Back to Home <ArrowRight className="ml-1.5 w-4 h-4" />
                </Link>
              </div>
            ) : (
              <div className="blog-grid grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {blogs.map((blog) => (
                  <Link
                    key={blog.id}
                    href={`/blog/${blog.slug}`}
                    className="blog-card group block"
                  >
                    <div className="aspect-[16/10] rounded-2xl bg-gradient-to-br from-vare-purple to-violet-600 mb-6 overflow-hidden relative">
                      {blog.featuredImage ? (
                        <img
                          src={blog.featuredImage}
                          alt={blog.title}
                          className="w-full h-full object-cover"
                          onError={(e) => { (e.target as HTMLImageElement).style.display = 'none' }}
                        />
                      ) : (
                        <div className="absolute inset-0 flex items-center justify-center">
                          <FileText className="w-12 h-12 text-white/20" />
                        </div>
                      )}
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all duration-500" />
                      <div className="absolute top-4 left-4">
                        <span className="px-3 py-1 rounded-full bg-white/90 text-vare-purple text-xs font-medium">
                          {blog.category || 'General'}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 mb-3 text-vare-gray text-sm">
                      {blog.authorName && (
                        <span className="flex items-center gap-1">
                          <User className="w-3.5 h-3.5" />
                          {blog.authorName}
                        </span>
                      )}
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5" />
                        {formatDate(blog.publishedAt || blog.createdAt)}
                      </span>
                    </div>
                    <h3 className="text-lg font-bold text-vare-slate mb-2 group-hover:text-vare-purple transition-colors duration-300 line-clamp-2">
                      {blog.title}
                    </h3>
                    <p className="text-vare-gray text-sm leading-relaxed line-clamp-2">{blog.excerpt}</p>
                    <div className="mt-4 flex items-center text-vare-purple font-medium text-sm opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-1 group-hover:translate-y-0">
                      Read More <ArrowRight className="ml-1.5 w-4 h-4" />
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* Newsletter Subscription */}
        <section ref={newsletterRef} className="py-24 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-vare-purple via-vare-purple-light to-vare-dark" />
          <div className="absolute inset-0">
            <div className="absolute top-10 left-10 w-72 h-72 bg-white/5 rounded-full blur-3xl" />
            <div className="absolute bottom-10 right-10 w-96 h-96 bg-white/5 rounded-full blur-3xl" />
          </div>
          <div className="relative z-10 max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="newsletter-anim w-16 h-16 rounded-2xl bg-white/10 backdrop-blur-sm flex items-center justify-center mx-auto mb-8 border border-white/20">
              <Mail className="w-8 h-8 text-white" />
            </div>
            <h2 className="newsletter-anim text-3xl md:text-4xl font-bold text-white mb-4">
              Stay Updated
            </h2>
            <p className="newsletter-anim text-white/70 text-lg leading-relaxed mb-10 max-w-xl mx-auto">
              Subscribe to our newsletter for the latest insights, tips, and industry news delivered straight to your inbox.
            </p>
            {subscribed ? (
              <div className="newsletter-anim bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
                <div className="w-14 h-14 rounded-full bg-emerald-500/20 flex items-center justify-center mx-auto mb-4">
                  <svg className="w-7 h-7 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h3 className="text-xl font-bold text-white mb-2">You&apos;re Subscribed!</h3>
                <p className="text-white/70">Welcome aboard! Check your inbox for a confirmation email.</p>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="newsletter-anim">
                <div className="flex flex-col sm:flex-row gap-3 max-w-lg mx-auto">
                  <div className="flex-1 relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Enter your email address"
                      className="w-full pl-12 pr-4 py-4 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 text-white placeholder-white/40 text-sm focus:outline-none focus:ring-2 focus:ring-white/30 focus:border-white/40 transition-all"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={subscribing}
                    className="px-8 py-4 bg-white text-vare-purple font-semibold rounded-xl hover:shadow-lg hover:shadow-white/25 transform hover:-translate-y-0.5 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    {subscribing ? (
                      <>
                        <div className="w-4 h-4 border-2 border-vare-purple/30 border-t-vare-purple rounded-full animate-spin" />
                        <span>Subscribing...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>Subscribe</span>
                      </>
                    )}
                  </button>
                </div>
                <p className="newsletter-anim text-white/40 text-sm mt-4">
                  Join 5,000+ subscribers. No spam, unsubscribe anytime.
                </p>
              </form>
            )}
          </div>
        </section>
        {/* CTA - Need Help With Your Project? */}
        <section className="py-24 gradient-purple-dark relative overflow-hidden">
          <div className="absolute inset-0">
            <div className="absolute top-10 left-10 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl" />
            <div className="absolute bottom-10 right-10 w-72 h-72 bg-purple-400/10 rounded-full blur-3xl" />
          </div>
          <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Need Help With Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-vare-gold to-yellow-300">Project?</span>
            </h2>
            <p className="text-white/70 text-lg mb-8 max-w-2xl mx-auto">
              Our team of experts is ready to turn your ideas into reality. Get a free consultation and see how we can help your business grow.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/contact" className="inline-flex items-center justify-center px-8 py-4 text-base font-medium text-vare-purple bg-white rounded-xl hover:shadow-2xl hover:shadow-white/25 transform hover:-translate-y-1 transition-all duration-300">
                Get a Free Quote <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
              <Link href="/services" className="inline-flex items-center justify-center px-8 py-4 text-base font-medium text-white border-2 border-white/30 rounded-xl hover:bg-white/10 hover:border-white/50 transition-all duration-300">
                View Our Services
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}

function Star({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="currentColor"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
    </svg>
  );
}
