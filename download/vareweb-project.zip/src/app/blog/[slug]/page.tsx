'use client';

import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import ReactMarkdown from 'react-markdown';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import { ArrowLeft, Calendar, User, Tag } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface BlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  category: string;
  tags: string;
  featuredImage: string;
  authorName: string;
  publishedAt: string;
  createdAt: string;
  status: string;
}

export default function BlogPostPage() {
  const params = useParams();
  const slug = params.slug as string;
  const [blog, setBlog] = useState<BlogPost | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetch('/api/blogs?status=PUBLISHED&limit=100')
      .then((r) => r.json())
      .then((data) => {
        const posts = data.data || data.posts || [];
        const found = posts.find((p: BlogPost) => p.slug === slug);
        if (found) {
          setBlog(found);
        } else {
          setNotFound(true);
        }
      })
      .catch(() => {
        setNotFound(true);
      })
      .finally(() => setLoading(false));
  }, [slug]);

  useEffect(() => {
    if (contentRef.current) {
      const ctx = gsap.context(() => {
        gsap.fromTo(
          contentRef.current!.querySelectorAll('.blog-animate'),
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.6, stagger: 0.1, ease: 'power3.out' }
        );
      });
      return () => ctx.revert();
    }
  }, [!loading]);

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  };

  if (loading) {
    return (
      <>
        <Navigation />
        <main className="pt-32 pb-24">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-48 mb-6" />
            <div className="h-10 bg-gray-200 rounded w-full mb-4" />
            <div className="h-10 bg-gray-200 rounded w-3/4 mb-8" />
            <div className="space-y-3">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="h-4 bg-gray-200 rounded" style={{ width: `${90 - i * 5}%` }} />
              ))}
            </div>
          </div>
        </main>
        <Footer />
      </>
    );
  }

  if (notFound || !blog) {
    return (
      <>
        <Navigation />
        <main className="pt-32 pb-24 text-center">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-4xl font-bold text-vare-slate mb-4">Post Not Found</h1>
            <p className="text-vare-gray text-lg mb-8">The blog post you are looking for does not exist or may have been removed.</p>
            <Link
              href="/blog"
              className="inline-flex items-center text-vare-purple font-medium hover:underline"
            >
              <ArrowLeft className="mr-1.5 w-4 h-4" /> Back to Blog
            </Link>
          </div>
        </main>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Navigation />
      <main>
        {/* Hero Banner */}
        {blog.featuredImage && (
          <div className="relative h-[300px] md:h-[400px] gradient-purple-dark overflow-hidden">
            <img
              src={blog.featuredImage}
              alt={blog.title}
              className="absolute inset-0 w-full h-full object-cover opacity-40"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-vare-slate/90 to-transparent" />
          </div>
        )}

        {/* Content */}
        <article ref={contentRef} className="py-16 bg-white">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Back link */}
            <Link
              href="/blog"
              className="blog-animate inline-flex items-center text-vare-gray hover:text-vare-purple text-sm font-medium mb-8 opacity-0 transition-colors"
            >
              <ArrowLeft className="mr-1.5 w-4 h-4" /> Back to Blog
            </Link>

            {/* Category */}
            {blog.category && (
              <span className="blog-animate inline-block px-3 py-1 rounded-full bg-vare-ice text-vare-purple text-sm font-medium mb-4 opacity-0">
                {blog.category}
              </span>
            )}

            {/* Title */}
            <h1 className="blog-animate text-3xl md:text-4xl lg:text-5xl font-bold text-vare-slate mb-6 leading-tight opacity-0">
              {blog.title}
            </h1>

            {/* Meta */}
            <div className="blog-animate flex flex-wrap items-center gap-4 mb-8 text-vare-gray text-sm opacity-0">
              {blog.authorName && (
                <span className="flex items-center gap-1.5">
                  <User className="w-4 h-4" />
                  {blog.authorName}
                </span>
              )}
              <span className="flex items-center gap-1.5">
                <Calendar className="w-4 h-4" />
                {formatDate(blog.publishedAt || blog.createdAt)}
              </span>
              {blog.tags && (
                <span className="flex items-center gap-1.5">
                  <Tag className="w-4 h-4" />
                  {blog.tags}
                </span>
              )}
            </div>

            {/* Excerpt */}
            {blog.excerpt && (
              <p className="blog-animate text-lg text-vare-gray leading-relaxed mb-10 font-medium opacity-0">
                {blog.excerpt}
              </p>
            )}

            {/* Divider */}
            <hr className="blog-animate border-gray-100 mb-10 opacity-0" />

            {/* Markdown Content */}
            <div className="blog-animate prose prose-lg prose-slate max-w-none opacity-0
              prose-headings:text-vare-slate prose-headings:font-bold
              prose-h2:text-2xl prose-h2:mt-10 prose-h2:mb-4
              prose-h3:text-xl prose-h3:mt-8 prose-h3:mb-3
              prose-p:text-vare-gray prose-p:leading-relaxed prose-p:mb-4
              prose-a:text-vare-purple prose-a:no-underline hover:prose-a:underline
              prose-strong:text-vare-slate
              prose-ul:my-4 prose-ol:my-4
              prose-li:text-vare-gray prose-li:leading-relaxed
              prose-code:text-vare-purple prose-code:bg-vare-ice prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded prose-code:text-sm
              prose-pre:bg-vare-slate prose-pre:text-white prose-pre:rounded-xl prose-pre:p-6
              prose-blockquote:border-l-4 prose-blockquote:border-vare-purple prose-blockquote:pl-6 prose-blockquote:italic prose-blockquote:text-vare-gray
              prose-img:rounded-xl prose-img:shadow-lg
              prose-hr:border-gray-200
            ">
              <ReactMarkdown>{blog.content}</ReactMarkdown>
            </div>

            {/* Bottom */}
            <hr className="border-gray-100 mt-12 mb-8" />
            <div className="text-center">
              <Link
                href="/blog"
                className="inline-flex items-center text-vare-purple font-medium hover:underline"
              >
                <ArrowLeft className="mr-1.5 w-4 h-4" /> Back to Blog
              </Link>
            </div>
          </div>
        </article>
      </main>
      <Footer />
    </>
  );
}
