'use client'

import { useState, useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import {
  Briefcase,
  MapPin,
  Clock,
  DollarSign,
  Users,
  ChevronDown,
  ChevronUp,
  Send,
  Loader2,
  Building2,
  Globe,
  FileText,
  ArrowRight,
  Star,
  Zap,
  Heart,
  Target,
  Quote,
  Camera,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog'
import { Card, CardContent } from '@/components/ui/card'
import { toast } from 'sonner'
import Navigation from '@/components/Navigation'
import Footer from '@/components/Footer'
import PageDecorations from '@/components/PageDecorations'


gsap.registerPlugin(ScrollTrigger)

interface JobListing {
  id: string
  title: string
  department: string
  location: string
  type: string
  salary: string | null
  description: string
  requirements: string
  isActive: boolean
}

const perks = [
  { icon: Zap, title: 'Fast Growth', description: 'Work on cutting-edge projects and grow your skills rapidly' },
  { icon: Heart, title: 'Health & Wellness', description: 'Comprehensive health insurance and wellness programs' },
  { icon: Globe, title: 'Remote Friendly', description: 'Work from anywhere with flexible hours and remote options' },
  { icon: Target, title: 'Learning Budget', description: 'Dedicated budget for courses, conferences, and certifications' },
  { icon: Star, title: 'Competitive Pay', description: 'Industry-leading compensation with performance bonuses' },
  { icon: Users, title: 'Great Team', description: 'Collaborative, supportive team of talented professionals' },
]

const testimonials = [
  {
    quote: "Joining VareWeb was the best career decision I've made. The growth opportunities are endless and the team is incredibly supportive.",
    name: 'Alex R.',
    role: 'Senior Developer',
    tenure: '3 years at VareWeb',
  },
  {
    quote: "The remote-first culture here gives me the freedom to do my best work while maintaining a great work-life balance.",
    name: 'Sarah M.',
    role: 'UX Designer',
    tenure: '2 years at VareWeb',
  },
  {
    quote: "I've learned more in my first year at VareWeb than in the previous five years combined. The learning culture is unmatched.",
    name: 'David K.',
    role: 'Project Manager',
    tenure: '1 year at VareWeb',
  },
]

const galleryItems = [
  { title: 'Team Offsite 2024', gradient: 'from-vare-purple to-purple-700' },
  { title: 'Hackathon Winners', gradient: 'from-blue-600 to-cyan-500' },
  { title: 'Annual Celebration', gradient: 'from-amber-400 to-vare-gold' },
  { title: 'Remote Team Meetup', gradient: 'from-teal-500 to-emerald-500' },
  { title: 'Workshop Session', gradient: 'from-pink-500 to-rose-400' },
  { title: 'Team Building Day', gradient: 'from-indigo-600 to-violet-500' },
]

export default function CareersPage() {
  const [jobs, setJobs] = useState<JobListing[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedJob, setSelectedJob] = useState<JobListing | null>(null)
  const [showApplyForm, setShowApplyForm] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [expandedJob, setExpandedJob] = useState<string | null>(null)
  const [form, setForm] = useState({
    fullName: '', email: '', phone: '', portfolioUrl: '', linkedinUrl: '',
    experience: '', education: '', skills: '', coverLetter: '',
  })
  const heroRef = useRef<HTMLDivElement>(null)
  const statsRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    fetch('/api/careers')
      .then(res => res.json())
      .then(data => {
        setJobs(data.data || [])
        setLoading(false)
      })
      .catch(() => setLoading(false))

    const ctx = gsap.context(() => {
      if (heroRef.current) {
        gsap.fromTo(heroRef.current.querySelectorAll('.animate-hero'),
          { y: 60, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.8, stagger: 0.15, ease: 'power3.out', delay: 0.5 }
        )
      }
      if (statsRef.current) {
        gsap.fromTo(statsRef.current.querySelectorAll('.animate-stat'),
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.6, stagger: 0.1, ease: 'power2.out', scrollTrigger: { trigger: statsRef.current, start: 'top 85%' } }
        )
      }
      gsap.utils.toArray<HTMLElement>('.animate-perk').forEach((el) => {
        gsap.fromTo(el, { y: 50, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.6, ease: 'power2.out', scrollTrigger: { trigger: el, start: 'top 88%' } }
        )
      })
      gsap.utils.toArray<HTMLElement>('.animate-job').forEach((el) => {
        gsap.fromTo(el, { x: -30, opacity: 0 },
          { x: 0, opacity: 1, duration: 0.5, ease: 'power2.out', scrollTrigger: { trigger: el, start: 'top 90%' } }
        )
      })
      // Testimonials animation
      gsap.fromTo(
        '.testimonials-header',
        { y: 30, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.7, ease: 'power3.out', scrollTrigger: { trigger: '#testimonials', start: 'top 75%' } }
      )
      gsap.utils.toArray<HTMLElement>('.testimonial-card').forEach((el) => {
        gsap.fromTo(el, { y: 50, opacity: 0, scale: 0.95 },
          { y: 0, opacity: 1, scale: 1, duration: 0.6, ease: 'power3.out', scrollTrigger: { trigger: el, start: 'top 88%' } }
        )
      })
      // Gallery animation
      gsap.fromTo(
        '.gallery-header',
        { y: 30, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.7, ease: 'power3.out', scrollTrigger: { trigger: '#gallery', start: 'top 75%' } }
      )
      gsap.utils.toArray<HTMLElement>('.gallery-card').forEach((el) => {
        gsap.fromTo(el, { y: 40, opacity: 0, scale: 0.95 },
          { y: 0, opacity: 1, scale: 1, duration: 0.5, ease: 'power3.out', scrollTrigger: { trigger: el, start: 'top 90%' } }
        )
      })
    })
    return () => ctx.revert()
  }, [])

  const handleApply = (job: JobListing) => {
    setSelectedJob(job)
    setShowApplyForm(true)
    setForm({ fullName: '', email: '', phone: '', portfolioUrl: '', linkedinUrl: '', experience: '', education: '', skills: '', coverLetter: '' })
  }

  const handleSubmitApplication = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedJob) return
    setSubmitting(true)
    try {
      const res = await fetch('/api/careers/apply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, jobId: selectedJob.id }),
      })
      const json = await res.json()
      if (res.ok) {
        toast.success('Application submitted successfully!')
        setShowApplyForm(false)
        setSelectedJob(null)
      } else {
        toast.error(json.error || 'Failed to submit application')
      }
    } catch {
      toast.error('Failed to submit application')
    } finally {
      setSubmitting(false)
    }
  }

  const typeColors: Record<string, string> = {
    'Full-Time': 'bg-emerald-100 text-emerald-700',
    'Part-Time': 'bg-blue-100 text-blue-700',
    'Contract': 'bg-amber-100 text-amber-700',
    'Internship': 'bg-purple-100 text-purple-700',
  }

  return (
    <>
      <Navigation />
      <PageDecorations />

      {/* Hero */}
      <section ref={heroRef} className="relative min-h-[85vh] flex items-center gradient-purple-dark overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-20 right-20 w-72 h-72 rounded-full bg-vare-purple-light/20 blur-3xl" />
          <div className="absolute bottom-20 left-20 w-96 h-96 rounded-full bg-vare-purple/30 blur-3xl" />
          <div className="absolute inset-0 opacity-5" style={{ backgroundImage: 'radial-gradient(circle, rgba(255,255,255,0.3) 1px, transparent 1px)', backgroundSize: '30px 30px' }} />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
          <div className="max-w-3xl">
            <Badge className="animate-hero bg-white/10 text-white/90 border-white/20 mb-6 px-4 py-1.5 text-sm">
              <Briefcase className="h-3.5 w-3.5 mr-2" />
              We&apos;re Hiring!
            </Badge>
            <h1 className="animate-hero text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6">
              Build Your Future
              <br />
              <span className="bg-gradient-to-r from-purple-300 to-blue-300 bg-clip-text text-transparent">
                With VareWeb
              </span>
            </h1>
            <p className="animate-hero text-lg text-white/70 mb-8 max-w-xl leading-relaxed">
              Join our talented team and work on innovative projects that shape the digital landscape. We&apos;re looking for passionate individuals who thrive on creativity and collaboration.
            </p>
            <div className="animate-hero flex flex-wrap gap-4">
              <a href="#openings">
                <Button size="lg" className="bg-white text-vare-purple-dark hover:bg-white/90 font-semibold rounded-xl px-8 shadow-lg">
                  View Open Positions <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </a>
              <a href="#perks">
                <Button size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10 rounded-xl px-8">
                  Why Join Us
                </Button>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section ref={statsRef} className="relative -mt-16 z-20 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-2xl shadow-xl border border-vare-border p-6 sm:p-8">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
            {[
              { value: '50+', label: 'Team Members' },
              { value: '200+', label: 'Projects Delivered' },
              { value: '15+', label: 'Countries' },
              { value: '98%', label: 'Client Satisfaction' },
            ].map((stat) => (
              <div key={stat.label} className="animate-stat text-center">
                <p className="text-2xl sm:text-3xl font-bold text-gradient">{stat.value}</p>
                <p className="text-sm text-vare-gray mt-1">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Perks */}
      <section id="perks" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge className="bg-vare-purple/10 text-vare-purple border-vare-purple/20 mb-4">Benefits & Perks</Badge>
            <h2 className="text-3xl sm:text-4xl font-bold text-vare-slate mb-4">Why You&apos;ll Love Working Here</h2>
            <p className="text-vare-gray max-w-2xl mx-auto text-lg">
              We believe in creating an environment where talent thrives. Here&apos;s what makes VareWeb special.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {perks.map((perk) => (
              <Card key={perk.title} className="animate-perk border-vare-border hover:border-vare-purple/30 hover:shadow-lg transition-all duration-300 group">
                <CardContent className="p-6">
                  <div className="w-12 h-12 rounded-xl bg-vare-purple/10 flex items-center justify-center mb-4 group-hover:bg-vare-purple/20 transition-colors">
                    <perk.icon className="h-6 w-6 text-vare-purple" />
                  </div>
                  <h3 className="text-lg font-semibold text-vare-slate mb-2">{perk.title}</h3>
                  <p className="text-vare-gray text-sm leading-relaxed">{perk.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Open Positions */}
      <section id="openings" className="py-24 bg-vare-ice">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge className="bg-vare-purple/10 text-vare-purple border-vare-purple/20 mb-4">Open Positions</Badge>
            <h2 className="text-3xl sm:text-4xl font-bold text-vare-slate mb-4">Current Openings</h2>
            <p className="text-vare-gray max-w-2xl mx-auto text-lg">
              Find a role that matches your skills and passion. We&apos;re always looking for exceptional talent.
            </p>
          </div>

          {loading ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="bg-white rounded-xl p-6 border border-vare-border animate-pulse">
                  <div className="h-6 bg-vare-ice rounded w-1/3 mb-3" />
                  <div className="h-4 bg-vare-ice rounded w-1/4" />
                </div>
              ))}
            </div>
          ) : jobs.length === 0 ? (
            <div className="text-center py-16 bg-white rounded-2xl border border-vare-border">
              <Briefcase className="h-16 w-16 text-vare-gray/30 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-vare-slate mb-2">No Open Positions Right Now</h3>
              <p className="text-vare-gray max-w-md mx-auto">We&apos;re growing fast and new roles open regularly. Check back soon or explore our available departments below.</p>
              <div className="mt-8 grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-2xl mx-auto">
                {['Engineering', 'Design', 'Marketing', 'Operations'].map((dept) => (
                  <div key={dept} className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-vare-ice border border-vare-border text-sm font-medium text-vare-slate">
                    <Briefcase className="w-4 h-4 text-vare-purple" />
                    {dept}
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {jobs.map((job) => (
                <div key={job.id} className="animate-job bg-white rounded-xl border border-vare-border hover:border-vare-purple/30 hover:shadow-md transition-all duration-300 overflow-hidden">
                  <div className="p-6">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2 flex-wrap">
                          <h3 className="text-lg font-semibold text-vare-slate">{job.title}</h3>
                          <Badge className={typeColors[job.type] || 'bg-gray-100 text-gray-600'}>{job.type}</Badge>
                        </div>
                        <div className="flex flex-wrap gap-4 text-sm text-vare-gray">
                          <span className="flex items-center gap-1.5"><Building2 className="h-3.5 w-3.5" />{job.department}</span>
                          <span className="flex items-center gap-1.5"><MapPin className="h-3.5 w-3.5" />{job.location}</span>
                          {job.salary && <span className="flex items-center gap-1.5"><DollarSign className="h-3.5 w-3.5" />{job.salary}</span>}
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Button onClick={() => setExpandedJob(expandedJob === job.id ? null : job.id)} variant="ghost" size="sm" className="text-vare-gray hover:text-vare-purple">
                          {expandedJob === job.id ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                        </Button>
                        <Button onClick={() => handleApply(job)} className="bg-vare-purple hover:bg-vare-purple-light text-white rounded-lg">
                          Apply Now <ArrowRight className="ml-1 h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </div>
                  </div>
                  {expandedJob === job.id && (
                    <div className="px-6 pb-6 border-t border-vare-border pt-4">
                      <div className="grid md:grid-cols-2 gap-6">
                        <div>
                          <h4 className="font-semibold text-vare-slate mb-2">Description</h4>
                          <div className="text-sm text-vare-gray whitespace-pre-wrap leading-relaxed bg-vare-ice rounded-lg p-4">{job.description}</div>
                        </div>
                        <div>
                          <h4 className="font-semibold text-vare-slate mb-2">Requirements</h4>
                          <div className="text-sm text-vare-gray whitespace-pre-wrap leading-relaxed bg-vare-ice rounded-lg p-4">{job.requirements}</div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Employee Testimonials */}
      <section id="testimonials" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="testimonials-header text-center mb-16">
            <Badge className="bg-vare-purple/10 text-vare-purple border-vare-purple/20 mb-4">Team Culture</Badge>
            <h2 className="text-3xl sm:text-4xl font-bold text-vare-slate mb-4">Hear From Our Team</h2>
            <p className="text-vare-gray max-w-2xl mx-auto text-lg">
              What it&apos;s like to work at VareWeb — straight from the people who know best.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {testimonials.map((testimonial) => (
              <div
                key={testimonial.name}
                className="testimonial-card bg-white rounded-2xl p-8 border border-gray-100 hover:border-vare-purple/20 hover:shadow-xl transition-all duration-300 relative"
              >
                <div className="absolute -top-4 left-8 w-8 h-8 rounded-full gradient-purple flex items-center justify-center">
                  <Quote className="w-4 h-4 text-white" />
                </div>
                <div className="flex gap-0.5 mb-5 mt-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-vare-gold fill-vare-gold" />
                  ))}
                </div>
                <blockquote className="text-vare-slate text-sm leading-relaxed mb-6 italic">
                  &ldquo;{testimonial.quote}&rdquo;
                </blockquote>
                <div className="border-t border-gray-100 pt-5">
                  <p className="font-semibold text-vare-slate">{testimonial.name}</p>
                  <p className="text-vare-gray text-sm">{testimonial.role}</p>
                  <p className="text-vare-purple text-xs mt-1">{testimonial.tenure}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Life at VareWeb Gallery */}
      <section id="gallery" className="py-24 bg-vare-ice">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="gallery-header text-center mb-16">
            <Badge className="bg-vare-purple/10 text-vare-purple border-vare-purple/20 mb-4">Our Culture</Badge>
            <h2 className="text-3xl sm:text-4xl font-bold text-vare-slate mb-4">Life at VareWeb</h2>
            <p className="text-vare-gray max-w-2xl mx-auto text-lg">
              Moments from our team events and daily life — because we believe in working hard and celebrating together.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {galleryItems.map((item) => (
              <div
                key={item.title}
                className="gallery-card group relative rounded-2xl overflow-hidden aspect-[4/3] cursor-pointer"
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${item.gradient} transition-transform duration-500 group-hover:scale-110`} />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all duration-500" />
                <div className="absolute inset-0 flex items-center justify-center opacity-40 group-hover:opacity-0 transition-opacity duration-300">
                  <Camera className="w-12 h-12 text-white" />
                </div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center transform translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
                    <h3 className="text-xl font-bold text-white mb-1 drop-shadow-lg">{item.title}</h3>
                    <div className="w-10 h-0.5 bg-white/60 mx-auto rounded-full" />
                  </div>
                </div>
                <div className="absolute bottom-4 left-4 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                  <Camera className="w-5 h-5 text-white/70" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA - Join Talent Pool */}
      <section className="py-20 gradient-purple">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">Don&apos;t See the Right Role?</h2>
          <p className="text-white/70 text-lg mb-8 max-w-2xl mx-auto">
            New positions open all the time. Join our talent pool and be the first to know when your dream role becomes available.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            {jobs.length > 0 && (
              <a href="#openings">
                <Button size="lg" className="bg-white text-vare-purple-dark hover:bg-white/90 font-semibold rounded-xl px-8 shadow-lg">
                  View {jobs.length} Open Position{jobs.length > 1 ? 's' : ''} <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </a>
            )}
            <Button size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10 rounded-xl px-8" onClick={() => { window.scrollTo({ top: 0, behavior: 'smooth' }) }}>
              Back to Top <ChevronUp className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </section>

      {/* Apply Dialog - must be before Footer for proper layering */}
      <Dialog open={showApplyForm} onOpenChange={setShowApplyForm}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl">Apply for {selectedJob?.title}</DialogTitle>
            <DialogDescription>{selectedJob?.department} · {selectedJob?.location} · {selectedJob?.type}</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmitApplication} className="space-y-5 mt-4">
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-vare-slate flex items-center gap-2"><Users className="h-4 w-4" />Personal Information</h3>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="fullName">Full Name *</Label>
                  <Input id="fullName" required value={form.fullName} onChange={(e) => setForm(p => ({ ...p, fullName: e.target.value }))} placeholder="John Doe" className="border-vare-border" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email *</Label>
                  <Input id="email" type="email" required value={form.email} onChange={(e) => setForm(p => ({ ...p, email: e.target.value }))} placeholder="john@example.com" className="border-vare-border" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone *</Label>
                  <Input id="phone" required value={form.phone} onChange={(e) => setForm(p => ({ ...p, phone: e.target.value }))} placeholder="+1 (555) 000-0000" className="border-vare-border" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="linkedinUrl">LinkedIn URL</Label>
                  <Input id="linkedinUrl" value={form.linkedinUrl} onChange={(e) => setForm(p => ({ ...p, linkedinUrl: e.target.value }))} placeholder="https://linkedin.com/in/yourprofile" className="border-vare-border" />
                </div>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="portfolioUrl">Portfolio / Website URL</Label>
              <Input id="portfolioUrl" value={form.portfolioUrl} onChange={(e) => setForm(p => ({ ...p, portfolioUrl: e.target.value }))} placeholder="https://yourportfolio.com" className="border-vare-border" />
            </div>
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-vare-slate flex items-center gap-2"><FileText className="h-4 w-4" />Experience & Education</h3>
              <div className="space-y-2">
                <Label htmlFor="experience">Work Experience *</Label>
                <Textarea id="experience" required rows={4} value={form.experience} onChange={(e) => setForm(p => ({ ...p, experience: e.target.value }))} placeholder="Describe your relevant work experience..." className="border-vare-border resize-none" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="education">Education *</Label>
                <Textarea id="education" required rows={3} value={form.education} onChange={(e) => setForm(p => ({ ...p, education: e.target.value }))} placeholder="Your educational background..." className="border-vare-border resize-none" />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="skills">Skills *</Label>
              <Input id="skills" required value={form.skills} onChange={(e) => setForm(p => ({ ...p, skills: e.target.value }))} placeholder="React, Node.js, TypeScript, UI/UX, etc." className="border-vare-border" />
              <p className="text-xs text-vare-gray">Separate skills with commas</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="coverLetter">Cover Letter</Label>
              <Textarea id="coverLetter" rows={5} value={form.coverLetter} onChange={(e) => setForm(p => ({ ...p, coverLetter: e.target.value }))} placeholder="Tell us why you're a great fit for this role..." className="border-vare-border resize-none" />
            </div>
            <div className="flex justify-end gap-3 pt-2">
              <Button type="button" variant="outline" onClick={() => setShowApplyForm(false)} className="border-vare-border">Cancel</Button>
              <Button type="submit" disabled={submitting} className="bg-vare-purple hover:bg-vare-purple-light text-white">
                {submitting ? (<><Loader2 className="mr-2 h-4 w-4 animate-spin" />Submitting...</>) : (<><Send className="mr-2 h-4 w-4" />Submit Application</>)}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <Footer />
    </>
  )
}
