'use client';

import { useEffect, useRef } from 'react';
import Link from 'next/link';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import PageDecorations from '@/components/PageDecorations';
import {
  Monitor, Smartphone, RefreshCw, Palette, Search, ShoppingCart,
  ArrowRight, Layers, Code, Zap, TrendingUp, CheckCircle2,
  Code2, Server, Cloud, BarChart3, Star,
  Stethoscope, Landmark, GraduationCap, Building2, UtensilsCrossed, Plane, Cpu,
  Wrench, Workflow, Share2, FileText,
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const services = [
  {
    icon: Monitor,
    title: 'Custom Web Design',
    slug: 'custom-web-design',
    desc: 'Each website we create is meticulously crafted to deliver a 100% unique online experience tailored to your brand. Our expert designers transform your vision into a dynamic, custom design that enhances visibility and drives conversions.',
    desc2: 'We focus on creating pixel-perfect designs that not only look stunning but also function flawlessly across all platforms and devices.',
    color: 'from-purple-500 to-indigo-600',
    features: [
      'Bespoke design tailored to your brand identity',
      'Custom animations and interactive elements',
      'SEO-friendly architecture from the ground up',
      'Cross-browser compatibility assurance',
      'Scalable codebase for future growth',
    ],
  },
  {
    icon: Smartphone,
    title: 'Responsive Web Design',
    slug: 'responsive-web-design',
    desc: 'We deliver seamless user experiences across all devices. Our responsive designs adapt flawlessly to any screen size, ensuring a consistent, engaging experience for every visitor, no matter how they access your site.',
    desc2: 'From smartphones to large desktop monitors, your website will look and perform beautifully everywhere.',
    color: 'from-blue-500 to-cyan-500',
    features: [
      'Mobile-first design methodology',
      'Fluid grid layouts and flexible images',
      'Touch-optimized user interfaces',
      'Fast loading times on any device',
      'Consistent branding across breakpoints',
    ],
  },
  {
    icon: RefreshCw,
    title: 'Website Redesign',
    slug: 'website-redesign',
    desc: 'Breathe new life into your existing website with our comprehensive redesign services. We modernize outdated designs, improve user experience, and optimize for performance to keep your brand competitive.',
    desc2: 'Our redesign process preserves your SEO equity while dramatically improving visual appeal and user engagement.',
    color: 'from-emerald-500 to-teal-500',
    features: [
      'Complete visual overhaul and modernization',
      'Content strategy and information architecture',
      'Performance optimization and speed improvements',
      'SEO migration and 301 redirect management',
      'Analytics integration and conversion tracking',
    ],
  },
  {
    icon: Palette,
    title: 'UX/UI Design',
    slug: 'ux-ui-design',
    desc: 'Our UX/UI design process is rooted in research and user psychology. We create intuitive interfaces that delight users, reduce friction, and guide visitors seamlessly toward conversion points.',
    desc2: 'We combine beautiful aesthetics with data-driven design decisions to maximize your digital impact.',
    color: 'from-orange-500 to-red-500',
    features: [
      'User research and persona development',
      'Wireframing and interactive prototyping',
      'Usability testing and iterative refinement',
      'Accessibility compliance (WCAG standards)',
      'Design systems and component libraries',
    ],
  },
  {
    icon: Search,
    title: 'Search Engine Optimization',
    slug: 'search-engine-optimization',
    desc: 'Dominate search results with our data-driven SEO strategies. From technical optimization to content marketing, we ensure your website ranks higher and attracts qualified organic traffic consistently.',
    desc2: 'Our proven SEO methodologies have helped hundreds of businesses achieve first-page rankings and sustained organic growth.',
    color: 'from-violet-500 to-purple-600',
    features: [
      'Technical SEO audit and implementation',
      'Keyword research and content strategy',
      'On-page and off-page optimization',
      'Local SEO and Google Business setup',
      'Monthly reporting and performance analysis',
    ],
  },
  {
    icon: ShoppingCart,
    title: 'eCommerce Design & Development',
    slug: 'ecommerce-development',
    desc: 'Build powerful online stores that convert browsers into buyers. We create stunning eCommerce experiences with secure payment processing, inventory management, and seamless checkout flows.',
    desc2: 'From product catalogs to complex multi-vendor marketplaces, we have the expertise to build your ideal online store.',
    color: 'from-pink-500 to-rose-500',
    features: [
      'Custom storefront design and branding',
      'Secure payment gateway integration',
      'Inventory and order management systems',
      'Abandoned cart recovery solutions',
      'Multi-currency and multi-language support',
    ],
  },
  {
    icon: Wrench,
    title: 'Custom Software Development',
    slug: 'custom-software-development',
    desc: 'We build bespoke software solutions designed to solve your unique business challenges. From enterprise-level applications to specialized internal tools, our development team delivers robust, scalable software that streamlines your operations.',
    desc2: 'Every solution is architected with maintainability and future growth in mind, ensuring your investment pays dividends for years to come.',
    color: 'from-amber-500 to-orange-600',
    features: [
      'Full-stack custom application development',
      'API design and third-party integrations',
      'Legacy system modernization and migration',
      'Automated testing and CI/CD pipelines',
      'Comprehensive technical documentation',
    ],
  },
  {
    icon: Workflow,
    title: 'GHL (GoHighLevel) Development & Automation',
    slug: 'ghl-development',
    desc: 'Unlock the full potential of GoHighLevel with our expert development and automation services. We build custom workflows, pipelines, and integrations that supercharge your lead generation, nurturing, and conversion processes.',
    desc2: 'From CRM customization to automated follow-up sequences, we help you leverage GHL to create a fully automated marketing machine that runs 24/7.',
    color: 'from-sky-500 to-blue-600',
    features: [
      'Custom CRM configuration and pipeline setup',
      'Automated workflow and trigger building',
      'Funnel design and landing page creation',
      'Third-party app integration and API connections',
      'SMS, email, and voicemail drop campaign automation',
    ],
  },
  {
    icon: Smartphone,
    title: 'Mobile App Development',
    slug: 'mobile-app-development',
    desc: 'We design and develop high-performance mobile applications for iOS and Android that your users will love. Our apps combine stunning interfaces with seamless functionality to deliver exceptional mobile experiences.',
    desc2: 'Using modern cross-platform frameworks and native development, we ensure your app performs flawlessly while minimizing development costs and time to market.',
    color: 'from-teal-500 to-emerald-600',
    features: [
      'Native and cross-platform app development',
      'Intuitive UI/UX design for mobile',
      'Push notifications and real-time messaging',
      'App Store optimization and publishing support',
      'Ongoing maintenance and performance monitoring',
    ],
  },
  {
    icon: TrendingUp,
    title: 'Digital Marketing & PPC',
    slug: 'digital-marketing',
    desc: 'Drive qualified traffic and maximize your return on ad spend with our data-driven digital marketing and pay-per-click campaigns. We craft targeted strategies across Google Ads, social media platforms, and display networks.',
    desc2: 'Our team continuously monitors, tests, and optimizes every campaign to ensure you get the highest possible conversion rates at the lowest cost per acquisition.',
    color: 'from-rose-500 to-pink-600',
    features: [
      'Google Ads and Bing Ads campaign management',
      'Social media advertising across all platforms',
      'Retargeting and remarketing strategies',
      'Conversion rate optimization and A/B testing',
      'Detailed analytics and ROI reporting',
    ],
  },
  {
    icon: Share2,
    title: 'Social Media Management',
    slug: 'social-media-management',
    desc: 'Build a powerful social media presence that engages your audience and drives brand awareness. We create compelling content, manage your profiles, and foster meaningful interactions across all major platforms.',
    desc2: 'Our social strategies are designed to grow your following organically while amplifying reach through targeted campaigns and community engagement.',
    color: 'from-fuchsia-500 to-purple-600',
    features: [
      'Content calendar creation and scheduling',
      'Platform-specific content design and copywriting',
      'Community management and audience engagement',
      'Social media analytics and performance reporting',
      'Influencer outreach and partnership coordination',
    ],
  },
  {
    icon: Palette,
    title: 'Brand Identity & Logo Design',
    slug: 'brand-identity-design',
    desc: 'Establish a memorable and cohesive brand identity that sets you apart from the competition. Our designers craft stunning logos, color palettes, typography systems, and brand guidelines that resonate with your target audience.',
    desc2: 'We go beyond aesthetics to build brand strategies that communicate your values, evoke emotion, and create lasting connections with your customers.',
    color: 'from-red-500 to-rose-600',
    features: [
      'Custom logo design with multiple concepts',
      'Complete brand style guide development',
      'Business card and stationery design',
      'Brand voice and messaging framework',
      'Social media brand kit and templates',
    ],
  },
  {
    icon: FileText,
    title: 'Content Writing & Strategy',
    slug: 'content-writing-strategy',
    desc: 'Engage your audience with compelling, SEO-optimized content that drives organic traffic and establishes your authority. Our experienced writers create blog posts, whitepapers, case studies, and website copy that convert.',
    desc2: 'We develop comprehensive content strategies aligned with your business goals, ensuring every piece of content serves a purpose in your marketing funnel.',
    color: 'from-lime-500 to-green-600',
    features: [
      'Blog posts and article writing',
      'SEO keyword research and content planning',
      'Whitepapers and e-book development',
      'Website copy and product descriptions',
      'Content performance tracking and optimization',
    ],
  },
  {
    icon: Cloud,
    title: 'Cloud Solutions & Hosting',
    slug: 'cloud-solutions-hosting',
    desc: 'Ensure your digital infrastructure is fast, secure, and scalable with our comprehensive cloud solutions and managed hosting services. We architect cloud environments that handle traffic spikes gracefully and keep your applications running 24/7.',
    desc2: 'From AWS and Google Cloud to specialized hosting configurations, we optimize your infrastructure for performance, security, and cost efficiency.',
    color: 'from-cyan-500 to-teal-600',
    features: [
      'Cloud architecture design and migration',
      'Managed hosting and server monitoring',
      'SSL certificates and security hardening',
      'Automatic backups and disaster recovery',
      'CDN setup and global performance optimization',
    ],
  },
];

const steps = [
  { num: '01', title: 'Planning', desc: 'We dive deep into your business goals, audience, and competition to create a strategic roadmap for success.', icon: Search },
  { num: '02', title: 'Design', desc: 'Our creative team crafts pixel-perfect designs and builds robust, scalable solutions using cutting-edge technology.', icon: Code },
  { num: '03', title: 'Testing', desc: 'Every element is rigorously tested across devices and browsers before we deploy your project to the world.', icon: Zap },
  { num: '04', title: 'Support', desc: 'We provide ongoing support and optimization to ensure your digital presence continues to evolve and succeed.', icon: TrendingUp },
];

const techCategories = [
  {
    icon: Code2,
    title: 'Frontend',
    color: 'from-vare-purple to-vare-purple-light',
    technologies: ['React', 'Next.js', 'Vue.js', 'Angular', 'TypeScript', 'Tailwind CSS', 'GSAP', 'Framer Motion'],
  },
  {
    icon: Server,
    title: 'Backend',
    color: 'from-vare-purple-light to-[#7c4dbb]',
    technologies: ['Node.js', 'Python', 'Django', 'Express.js', 'PostgreSQL', 'MongoDB', 'Redis', 'GraphQL'],
  },
  {
    icon: Palette,
    title: 'Design',
    color: 'from-[#7c4dbb] to-vare-gold',
    technologies: ['Figma', 'Adobe XD', 'Photoshop', 'Illustrator', 'After Effects', 'Sketch'],
  },
  {
    icon: Cloud,
    title: 'DevOps',
    color: 'from-vare-gold to-[#d97706]',
    technologies: ['AWS', 'Vercel', 'Docker', 'GitHub Actions', 'Nginx', 'Cloudflare'],
  },
];

const caseStudies = [
  {
    title: 'TechStart E-Commerce Redesign',
    description: 'Complete overhaul of an e-commerce platform resulting in massive growth',
    stats: [
      { value: '+150%', label: 'Revenue' },
      { value: '+200%', label: 'Users' },
      { value: '-60%', label: 'Bounce Rate' },
    ],
    tags: ['Web Design', 'eCommerce', 'SEO'],
    gradient: 'from-vare-purple to-vare-purple-light',
  },
  {
    title: 'HealthTech Patient Portal',
    description: 'Building a HIPAA-compliant healthcare platform serving 100K+ patients',
    stats: [
      { value: '100K+', label: 'Patients' },
      { value: '99.9%', label: 'Uptime' },
      { value: '4.9/5', label: 'Rating' },
    ],
    tags: ['Healthcare', 'Web App', 'Security'],
    gradient: 'from-vare-purple-light to-[#7c4dbb]',
  },
  {
    title: 'GlobalFood Delivery App',
    description: 'Mobile-first platform connecting restaurants with customers across 50 cities',
    stats: [
      { value: '50', label: 'Cities' },
      { value: '500K', label: 'Downloads' },
      { value: '4.8/5', label: 'Rating' },
    ],
    tags: ['Mobile App', 'UI/UX', 'Backend'],
    gradient: 'from-[#7c4dbb] to-vare-gold',
  },
];

const industries = [
  { name: 'Healthcare & Medical', icon: Stethoscope, description: 'HIPAA-compliant solutions for clinics, hospitals, and telehealth platforms.' },
  { name: 'E-Commerce & Retail', icon: ShoppingCart, description: 'Scalable storefronts and marketplaces that drive conversions.' },
  { name: 'Finance & Banking', icon: Landmark, description: 'Secure fintech applications with robust data protection.' },
  { name: 'Education & E-Learning', icon: GraduationCap, description: 'Engaging learning platforms and course management systems.' },
  { name: 'Real Estate', icon: Building2, description: 'Property listing portals and virtual tour experiences.' },
  { name: 'Food & Restaurant', icon: UtensilsCrossed, description: 'Ordering systems and delivery apps for the hospitality sector.' },
  { name: 'Travel & Hospitality', icon: Plane, description: 'Booking platforms and travel management solutions.' },
  { name: 'Technology & SaaS', icon: Cpu, description: 'Product design and development for tech companies worldwide.' },
];

export default function ServicesPage() {
  const heroRef = useRef<HTMLElement>(null);
  const servicesRef = useRef<HTMLElement>(null);
  const processRef = useRef<HTMLElement>(null);
  const techStackRef = useRef<HTMLElement>(null);
  const caseStudiesRef = useRef<HTMLElement>(null);
  const industriesRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Hero animations
      if (heroRef.current) {
        gsap.fromTo(
          heroRef.current.querySelectorAll('.hero-anim'),
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, stagger: 0.15, ease: 'power3.out' }
        );
      }

      // Service cards
      if (servicesRef.current) {
        gsap.fromTo(
          servicesRef.current.querySelector('.section-header'),
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, ease: 'power3.out', scrollTrigger: { trigger: servicesRef.current, start: 'top 75%' } }
        );
        gsap.fromTo(
          servicesRef.current.querySelectorAll('.service-card'),
          { y: 60, opacity: 0, scale: 0.96 },
          { y: 0, opacity: 1, scale: 1, duration: 0.6, stagger: 0.1, ease: 'power3.out', scrollTrigger: { trigger: servicesRef.current.querySelector('.services-grid'), start: 'top 80%' } }
        );
      }

      // Process steps
      if (processRef.current) {
        gsap.fromTo(
          processRef.current.querySelectorAll('.process-step'),
          { x: -40, opacity: 0 },
          { x: 0, opacity: 1, duration: 0.6, stagger: 0.2, ease: 'power3.out', scrollTrigger: { trigger: processRef.current, start: 'top 75%' } }
        );
      }

      // Technology Stack
      if (techStackRef.current) {
        gsap.fromTo(
          techStackRef.current.querySelector('.section-header'),
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, ease: 'power3.out', scrollTrigger: { trigger: techStackRef.current, start: 'top 75%' } }
        );
        gsap.fromTo(
          techStackRef.current.querySelectorAll('.tech-card'),
          { y: 50, opacity: 0, scale: 0.95 },
          { y: 0, opacity: 1, scale: 1, duration: 0.6, stagger: 0.15, ease: 'power3.out', scrollTrigger: { trigger: techStackRef.current.querySelector('.tech-grid'), start: 'top 80%' } }
        );
      }

      // Case Studies
      if (caseStudiesRef.current) {
        gsap.fromTo(
          caseStudiesRef.current.querySelector('.section-header'),
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, ease: 'power3.out', scrollTrigger: { trigger: caseStudiesRef.current, start: 'top 75%' } }
        );
        gsap.fromTo(
          caseStudiesRef.current.querySelectorAll('.case-card'),
          { y: 60, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, stagger: 0.2, ease: 'power3.out', scrollTrigger: { trigger: caseStudiesRef.current.querySelector('.case-grid'), start: 'top 80%' } }
        );
      }

      // Industries
      if (industriesRef.current) {
        gsap.fromTo(
          industriesRef.current.querySelector('.section-header'),
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, ease: 'power3.out', scrollTrigger: { trigger: industriesRef.current, start: 'top 75%' } }
        );
        gsap.fromTo(
          industriesRef.current.querySelectorAll('.industry-card'),
          { y: 40, opacity: 0, scale: 0.95 },
          { y: 0, opacity: 1, scale: 1, duration: 0.5, stagger: 0.08, ease: 'power3.out', scrollTrigger: { trigger: industriesRef.current.querySelector('.industries-grid'), start: 'top 80%' } }
        );
      }
    });
    return () => ctx.revert();
  }, []);

  return (
    <>
      <Navigation />
      <PageDecorations />
      <main>
        {/* Hero */}
        <section ref={heroRef} className="relative pt-32 pb-24 overflow-hidden gradient-purple-dark">
          <div className="absolute inset-0">
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(123,77,187,0.3),transparent_50%)]" />
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,rgba(58,26,112,0.4),transparent_50%)]" />
            <div className="absolute top-20 left-10 w-72 h-72 bg-purple-500/10 rounded-full blur-3xl" />
            <div className="absolute bottom-20 right-10 w-96 h-96 bg-purple-400/10 rounded-full blur-3xl" />
          </div>
          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <span className="hero-anim inline-flex items-center px-3 py-1 rounded-full glass-effect text-white/90 text-sm font-medium mb-6 opacity-0">
              <Layers className="w-4 h-4 mr-1.5" /> What We Do
            </span>
            <h1 className="hero-anim text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-6 opacity-0">
              Our <span className="text-transparent bg-clip-text bg-gradient-to-r from-vare-gold to-yellow-300">Services</span>
            </h1>
            <p className="hero-anim max-w-2xl mx-auto text-lg text-white/70 leading-relaxed opacity-0">
              We offer a full range of digital services to help your business grow. From stunning web design to powerful SEO strategies, we have the expertise to bring your vision to life.
            </p>
          </div>
        </section>

        {/* Services Grid */}
        <section ref={servicesRef} className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="section-header text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-vare-slate mb-4">
                Comprehensive <span className="text-gradient">Digital Solutions</span>
              </h2>
              <p className="text-vare-gray max-w-2xl mx-auto text-lg">
                Every service is delivered with our signature blend of creativity, technical excellence, and strategic thinking.
              </p>
            </div>

            <div className="services-grid grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {services.map((service, i) => (
                <div
                  key={i}
                  className="service-card group bg-white rounded-2xl p-8 border border-gray-100 hover:border-vare-purple/20 hover:shadow-xl hover:shadow-purple-500/5 transition-all duration-500"
                >
                  <div className={`w-14 h-14 rounded-xl bg-gradient-to-r ${service.color} flex items-center justify-center mb-6 transform group-hover:scale-110 transition-transform duration-300`}>
                    <service.icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-vare-slate mb-3 group-hover:text-vare-purple transition-colors duration-300">
                    {service.title}
                  </h3>
                  <p className="text-vare-gray text-sm leading-relaxed mb-3">{service.desc}</p>
                  <p className="text-vare-gray text-sm leading-relaxed mb-6">{service.desc2}</p>
                  <ul className="space-y-2.5 mb-8">
                    {service.features.map((feature, j) => (
                      <li key={j} className="flex items-start text-sm text-vare-slate">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 mr-2.5 flex-shrink-0 mt-0.5" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Link
                    href={`/services/${service.slug}`}
                    className="inline-flex items-center text-vare-purple font-medium text-sm group-hover:gap-2 transition-all duration-300"
                  >
                    Get Started <ArrowRight className="ml-1.5 w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Process */}
        <section ref={processRef} className="py-24 bg-vare-ice">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <span className="inline-flex items-center px-3 py-1 rounded-full bg-white text-vare-purple text-sm font-medium mb-4">
                <Layers className="w-4 h-4 mr-1.5" /> Our Process
              </span>
              <h2 className="text-3xl md:text-4xl font-bold text-vare-slate mb-4">
                How We <span className="text-gradient">Work</span>
              </h2>
              <p className="text-vare-gray max-w-2xl mx-auto text-lg">
                Our proven process ensures every project is delivered on time, on budget, and exceeds expectations.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {steps.map((step, i) => (
                <div key={i} className="process-step relative group">
                  <div className="text-6xl font-bold text-vare-purple/10 mb-4">{step.num}</div>
                  <div className="w-12 h-12 rounded-xl gradient-purple flex items-center justify-center mb-4 transform group-hover:scale-110 transition-transform duration-300">
                    <step.icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-lg font-bold text-vare-slate mb-2">{step.title}</h3>
                  <p className="text-vare-gray text-sm leading-relaxed">{step.desc}</p>
                  {i < steps.length - 1 && (
                    <div className="hidden lg:block absolute top-8 right-0 translate-x-1/2">
                      <ArrowRight className="w-6 h-6 text-vare-purple/20" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Technology Stack */}
        <section ref={techStackRef} className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="section-header text-center mb-16">
              <span className="inline-flex items-center px-3 py-1 rounded-full bg-vare-ice text-vare-purple text-sm font-medium mb-4">
                <Code2 className="w-4 h-4 mr-1.5" /> Tech Stack
              </span>
              <h2 className="text-3xl md:text-4xl font-bold text-vare-slate mb-4">
                Our <span className="text-gradient">Technology Stack</span>
              </h2>
              <p className="text-vare-gray max-w-2xl mx-auto text-lg">
                We leverage cutting-edge tools and technologies
              </p>
            </div>
            <div className="tech-grid grid grid-cols-1 md:grid-cols-2 gap-8">
              {techCategories.map((category, i) => (
                <div
                  key={i}
                  className="tech-card group relative rounded-2xl p-8 overflow-hidden transition-all duration-500 hover:shadow-xl hover:shadow-purple-500/5 hover:-translate-y-1"
                >
                  <div className={`absolute inset-0 bg-gradient-to-br ${category.color} opacity-[0.03] group-hover:opacity-[0.06] transition-opacity duration-500`} />
                  <div className="relative z-10">
                    <div className="flex items-center gap-3 mb-6">
                      <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${category.color} flex items-center justify-center shadow-lg shadow-vare-purple/20`}>
                        <category.icon className="w-6 h-6 text-white" />
                      </div>
                      <h3 className="text-xl font-bold text-vare-slate">{category.title}</h3>
                    </div>
                    <div className="flex flex-wrap gap-2.5">
                      {category.technologies.map((tech, j) => (
                        <span
                          key={j}
                          className="inline-flex items-center px-3.5 py-1.5 rounded-full text-sm font-medium bg-vare-ice text-vare-slate border border-vare-border/50 hover:border-vare-purple/30 hover:text-vare-purple hover:bg-vare-purple/5 transition-all duration-300"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Results & Case Study Highlights */}
        <section ref={caseStudiesRef} className="py-24 bg-vare-ice">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="section-header text-center mb-16">
              <span className="inline-flex items-center px-3 py-1 rounded-full bg-white text-vare-purple text-sm font-medium mb-4">
                <BarChart3 className="w-4 h-4 mr-1.5" /> Results
              </span>
              <h2 className="text-3xl md:text-4xl font-bold text-vare-slate mb-4">
                Real Results, <span className="text-gradient">Real Impact</span>
              </h2>
              <p className="text-vare-gray max-w-2xl mx-auto text-lg">
                Numbers that speak for themselves
              </p>
            </div>
            <div className="case-grid grid grid-cols-1 lg:grid-cols-3 gap-8">
              {caseStudies.map((study, i) => (
                <div
                  key={i}
                  className="case-card group relative rounded-2xl overflow-hidden transition-all duration-500 hover:shadow-2xl hover:shadow-vare-purple/10 hover:-translate-y-1"
                >
                  <div className={`absolute inset-0 bg-gradient-to-br ${study.gradient}`} />
                  <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(255,255,255,0.1),transparent_60%)]" />
                  <div className="relative z-10 p-8 flex flex-col h-full min-h-[380px]">
                    <div className="mb-6">
                      <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-sm flex items-center justify-center mb-5">
                        <TrendingUp className="w-6 h-6 text-white" />
                      </div>
                      <h3 className="text-xl font-bold text-white mb-3 leading-tight">{study.title}</h3>
                      <p className="text-white/75 text-sm leading-relaxed">{study.description}</p>
                    </div>
                    <div className="mt-auto space-y-4">
                      <div className="grid grid-cols-3 gap-3">
                        {study.stats.map((stat, j) => (
                          <div key={j} className="bg-white/10 backdrop-blur-sm rounded-xl p-3 text-center">
                            <div className="text-xl font-bold text-white">{stat.value}</div>
                            <div className="text-xs text-white/60 mt-0.5">{stat.label}</div>
                          </div>
                        ))}
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {study.tags.map((tag, j) => (
                          <span
                            key={j}
                            className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-white/10 text-white/80 backdrop-blur-sm"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Industries We Serve */}
        <section ref={industriesRef} className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="section-header text-center mb-16">
              <span className="inline-flex items-center px-3 py-1 rounded-full bg-vare-ice text-vare-purple text-sm font-medium mb-4">
                <Layers className="w-4 h-4 mr-1.5" /> Industries
              </span>
              <h2 className="text-3xl md:text-4xl font-bold text-vare-slate mb-4">
                Industries <span className="text-gradient">We Serve</span>
              </h2>
              <p className="text-vare-gray max-w-2xl mx-auto text-lg">
                Deep expertise across diverse sectors
              </p>
            </div>
            <div className="industries-grid grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {industries.map((industry, i) => (
                <div
                  key={i}
                  className="industry-card group rounded-2xl p-6 bg-white border border-gray-100 hover:border-vare-purple/20 hover:shadow-xl hover:shadow-purple-500/5 transition-all duration-500 hover:-translate-y-1 cursor-default"
                >
                  <div className="w-12 h-12 rounded-xl bg-vare-ice group-hover:bg-gradient-to-br group-hover:from-vare-purple group-hover:to-vare-purple-light flex items-center justify-center mb-5 transition-all duration-300">
                    <industry.icon className="w-6 h-6 text-vare-purple group-hover:text-white transition-colors duration-300" />
                  </div>
                  <h3 className="text-base font-bold text-vare-slate mb-2 group-hover:text-vare-purple transition-colors duration-300">
                    {industry.name}
                  </h3>
                  <p className="text-vare-gray text-sm leading-relaxed">{industry.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-24 bg-white relative overflow-hidden">
          <div className="absolute inset-0">
            <div className="absolute top-0 right-0 w-96 h-96 bg-vare-purple/5 rounded-full blur-3xl" />
            <div className="absolute bottom-0 left-0 w-72 h-72 bg-vare-gold/5 rounded-full blur-3xl" />
          </div>
          <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="gradient-purple rounded-3xl p-10 sm:p-14 lg:p-16 text-center relative overflow-hidden">
              <div className="absolute top-0 right-0 w-48 h-48 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2" />
              <div className="absolute bottom-0 left-0 w-36 h-36 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/2" />
              <div className="relative">
                <h2 className="text-3xl sm:text-4xl font-bold text-white mb-5 leading-tight">
                  Not Sure Which Service{' '}
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-vare-gold to-yellow-300">Fits Best?</span>
                </h2>
                <p className="text-white/70 text-base sm:text-lg mb-8 max-w-2xl mx-auto leading-relaxed">
                  Tell us about your project and we&apos;ll recommend the perfect combination of services tailored to your goals, timeline, and budget. No commitment, no pressure — just honest expert advice.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                  <Link
                    href="/contact"
                    className="inline-flex items-center px-8 py-4 text-base font-semibold text-vare-purple bg-white rounded-xl hover:shadow-2xl hover:shadow-white/25 transform hover:-translate-y-1 transition-all duration-300"
                  >
                    Book a Free Consultation <ArrowRight className="ml-2 w-5 h-5" />
                  </Link>
                  <Link
                    href="/pricing"
                    className="inline-flex items-center px-8 py-4 text-base font-medium text-white border-2 border-white/25 rounded-xl hover:bg-white/10 hover:border-white/40 transition-all duration-300"
                  >
                    View Pricing Plans
                  </Link>
                </div>
                <div className="mt-10 flex flex-wrap justify-center gap-8 text-white/50 text-sm">
                  <span className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> Free Strategy Session</span>
                  <span className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> Custom Roadmap</span>
                  <span className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> No Obligation</span>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
