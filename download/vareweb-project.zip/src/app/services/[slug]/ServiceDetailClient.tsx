'use client';

import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import {
  Layers, ArrowRight, CheckCircle2, Zap, Code, Search,
  BarChart3, BookOpen, ChevronDown,
} from 'lucide-react';
import { servicesData, type ServiceData } from './data';

gsap.registerPlugin(ScrollTrigger);

export default function ServiceDetailClient() {
  const params = useParams();
  const slug = params.slug as string;
  const service = servicesData.find((s) => s.slug === slug);

  const heroRef = useRef<HTMLElement>(null);
  const overviewRef = useRef<HTMLElement>(null);
  const featuresRef = useRef<HTMLElement>(null);
  const processRef = useRef<HTMLElement>(null);
  const techRef = useRef<HTMLElement>(null);
  const faqRef = useRef<HTMLElement>(null);
  const ctaRef = useRef<HTMLElement>(null);

  const [openFaq, setOpenFaq] = useState<number | null>(null);

  useEffect(() => {
    if (!service) return;
    const ctx = gsap.context(() => {
      if (heroRef.current) {
        gsap.fromTo(
          heroRef.current.querySelectorAll('.hero-anim'),
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, stagger: 0.12, ease: 'power3.out' }
        );
      }
      if (overviewRef.current) {
        gsap.fromTo(
          overviewRef.current.querySelectorAll('.ov-anim'),
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.6, stagger: 0.15, ease: 'power3.out', scrollTrigger: { trigger: overviewRef.current, start: 'top 75%' } }
        );
      }
      if (featuresRef.current) {
        gsap.fromTo(
          featuresRef.current.querySelector('.section-header'),
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.6, ease: 'power3.out', scrollTrigger: { trigger: featuresRef.current, start: 'top 75%' } }
        );
        gsap.fromTo(
          featuresRef.current.querySelectorAll('.feat-card'),
          { y: 60, opacity: 0, scale: 0.96 },
          { y: 0, opacity: 1, scale: 1, duration: 0.5, stagger: 0.1, ease: 'power3.out', scrollTrigger: { trigger: featuresRef.current.querySelector('.feat-grid'), start: 'top 80%' } }
        );
      }
      if (processRef.current) {
        gsap.fromTo(
          processRef.current.querySelectorAll('.proc-step'),
          { x: -40, opacity: 0 },
          { x: 0, opacity: 1, duration: 0.5, stagger: 0.15, ease: 'power3.out', scrollTrigger: { trigger: processRef.current, start: 'top 75%' } }
        );
      }
      if (techRef.current) {
        gsap.fromTo(
          techRef.current.querySelector('.section-header'),
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.6, ease: 'power3.out', scrollTrigger: { trigger: techRef.current, start: 'top 75%' } }
        );
        gsap.fromTo(
          techRef.current.querySelectorAll('.tech-pill'),
          { y: 30, opacity: 0, scale: 0.9 },
          { y: 0, opacity: 1, scale: 1, duration: 0.4, stagger: 0.06, ease: 'power3.out', scrollTrigger: { trigger: techRef.current.querySelector('.tech-pills'), start: 'top 80%' } }
        );
      }
      if (faqRef.current) {
        gsap.fromTo(
          faqRef.current.querySelector('.section-header'),
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.6, ease: 'power3.out', scrollTrigger: { trigger: faqRef.current, start: 'top 75%' } }
        );
        gsap.fromTo(
          faqRef.current.querySelectorAll('.faq-item'),
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.5, stagger: 0.1, ease: 'power3.out', scrollTrigger: { trigger: faqRef.current.querySelector('.faq-list'), start: 'top 80%' } }
        );
      }
      if (ctaRef.current) {
        gsap.fromTo(
          ctaRef.current.querySelectorAll('.cta-anim'),
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.6, stagger: 0.12, ease: 'power3.out', scrollTrigger: { trigger: ctaRef.current, start: 'top 75%' } }
        );
      }
    });
    return () => ctx.revert();
  }, [service]);

  if (!service) {
    return (
      <>
        <Navigation />
        <main className="min-h-screen flex items-center justify-center bg-white">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-vare-slate mb-4">Service Not Found</h1>
            <p className="text-vare-gray mb-8">The service you are looking for does not exist.</p>
            <Link href="/services" className="inline-flex items-center px-6 py-3 gradient-purple text-white rounded-xl font-medium hover:shadow-xl hover:shadow-purple-500/20 transition-all duration-300">
              <ArrowRight className="mr-2 w-4 h-4 rotate-180" /> Back to Services
            </Link>
          </div>
        </main>
        <Footer />
      </>
    );
  }

  const ServiceIcon = service.icon;

  return (
    <>
      <Navigation />
      <main>
        {/* ─── Hero Section ─── */}
        <section ref={heroRef} className="relative pt-32 pb-24 overflow-hidden gradient-purple-dark">
          <div className="absolute inset-0">
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(123,77,187,0.3),transparent_50%)]" />
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,rgba(58,26,112,0.4),transparent_50%)]" />
            <div className="absolute top-20 left-10 w-72 h-72 bg-purple-500/10 rounded-full blur-3xl" />
            <div className="absolute bottom-20 right-10 w-96 h-96 bg-purple-400/10 rounded-full blur-3xl" />
          </div>
          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            {/* Breadcrumb */}
            <nav className="hero-anim flex items-center justify-center gap-2 text-sm text-white/50 mb-8 opacity-0" aria-label="Breadcrumb">
              <Link href="/" className="hover:text-white/80 transition-colors">Home</Link>
              <span aria-hidden="true">/</span>
              <Link href="/services" className="hover:text-white/80 transition-colors">Services</Link>
              <span aria-hidden="true">/</span>
              <span className="text-white/80">{service.title}</span>
            </nav>

            {/* Badge */}
            <span className="hero-anim inline-flex items-center px-4 py-1.5 rounded-full glass-effect text-white/90 text-sm font-medium mb-6 opacity-0">
              <ServiceIcon className="w-4 h-4 mr-2" />
              {service.badge}
            </span>

            {/* Title */}
            <h1 className="hero-anim text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-6 opacity-0">
              {service.title.split(' ').map((word, i) => (
                i === 0 ? (
                  <span key={i} className="text-transparent bg-clip-text bg-gradient-to-r from-vare-gold to-yellow-300">{word} </span>
                ) : (
                  <span key={i}>{word} </span>
                )
              ))}
            </h1>

            {/* Description */}
            <p className="hero-anim max-w-3xl mx-auto text-lg text-white/70 leading-relaxed mb-10 opacity-0">
              {service.heroDesc}
            </p>

            {/* CTA Buttons */}
            <div className="hero-anim flex flex-col sm:flex-row gap-4 justify-center items-center opacity-0">
              <Link
                href="/contact"
                className="group relative inline-flex items-center px-8 py-4 text-base font-semibold text-vare-purple-dark bg-white rounded-xl hover:shadow-2xl hover:shadow-white/30 transform hover:-translate-y-1 transition-all duration-300"
              >
                <span className="relative z-10">Get a Quote</span>
                <ArrowRight className="ml-2 w-5 h-5 relative z-10 transform group-hover:translate-x-1 transition-transform duration-300" />
                <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-white to-yellow-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </Link>
              <Link
                href="/services"
                className="inline-flex items-center px-8 py-4 text-base font-medium text-white border-2 border-white/20 rounded-xl hover:bg-white/10 hover:border-white/40 backdrop-blur-sm transition-all duration-300"
              >
                View Pricing
              </Link>
            </div>
          </div>
        </section>

        {/* ─── Overview Section ─── */}
        <section ref={overviewRef} className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-16">
              <div className="lg:col-span-3">
                <span className="ov-anim inline-flex items-center px-3 py-1 rounded-full bg-vare-ice text-vare-purple text-sm font-medium mb-4 opacity-0">
                  <Layers className="w-4 h-4 mr-1.5" /> Overview
                </span>
                <h2 className="ov-anim text-3xl md:text-4xl font-bold text-vare-slate mb-6 opacity-0">
                  What This Service <span className="text-gradient">Includes</span>
                </h2>
                <p className="ov-anim text-vare-gray leading-relaxed mb-4 opacity-0">
                  {service.overviewP1}
                </p>
                <p className="ov-anim text-vare-gray leading-relaxed opacity-0">
                  {service.overviewP2}
                </p>
              </div>
              <div className="lg:col-span-2">
                <div className="ov-anim rounded-2xl bg-vare-ice p-6 opacity-0">
                  <h3 className="text-lg font-bold text-vare-slate mb-4">Key Highlights</h3>
                  <ul className="space-y-3">
                    {service.highlights.map((h, i) => (
                      <li key={i} className="flex items-start text-sm text-vare-slate">
                        <CheckCircle2 className="w-5 h-5 text-emerald-500 mr-3 flex-shrink-0 mt-0.5" />
                        <span>{h}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ─── Features Section ─── */}
        <section ref={featuresRef} className="py-24 bg-vare-ice">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="section-header text-center mb-16">
              <span className="inline-flex items-center px-3 py-1 rounded-full bg-white text-vare-purple text-sm font-medium mb-4">
                <Zap className="w-4 h-4 mr-1.5" /> Features
              </span>
              <h2 className="text-3xl md:text-4xl font-bold text-vare-slate mb-4">
                What You <span className="text-gradient">Get</span>
              </h2>
              <p className="text-vare-gray max-w-2xl mx-auto text-lg">
                Every aspect of our {service.title.toLowerCase()} service is designed to deliver maximum value and measurable results for your business.
              </p>
            </div>
            <div className="feat-grid grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {service.features.map((feat, i) => (
                <div
                  key={i}
                  className="feat-card group bg-white rounded-2xl p-8 border border-gray-100 hover:border-vare-purple/20 hover:shadow-xl hover:shadow-purple-500/5 transition-all duration-500"
                >
                  <div className="w-14 h-14 rounded-xl bg-vare-ice group-hover:bg-gradient-to-br group-hover:from-vare-purple group-hover:to-vare-purple-light flex items-center justify-center mb-6 transition-all duration-300">
                    <feat.icon className="w-7 h-7 text-vare-purple group-hover:text-white transition-colors duration-300" />
                  </div>
                  <h3 className="text-lg font-bold text-vare-slate mb-3 group-hover:text-vare-purple transition-colors duration-300">
                    {feat.title}
                  </h3>
                  <p className="text-vare-gray text-sm leading-relaxed">{feat.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ─── Process Section ─── */}
        <section ref={processRef} className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <span className="inline-flex items-center px-3 py-1 rounded-full bg-vare-ice text-vare-purple text-sm font-medium mb-4">
                <Layers className="w-4 h-4 mr-1.5" /> Our Process
              </span>
              <h2 className="text-3xl md:text-4xl font-bold text-vare-slate mb-4">
                How We Deliver <span className="text-gradient">{service.title}</span>
              </h2>
              <p className="text-vare-gray max-w-2xl mx-auto text-lg">
                Our proven methodology ensures consistent, high-quality results on every project.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {service.process.map((step, i) => (
                <div key={i} className="proc-step relative group">
                  <div className="text-6xl font-bold text-vare-purple/10 mb-4">{step.num}</div>
                  <div className="w-12 h-12 rounded-xl gradient-purple flex items-center justify-center mb-4 transform group-hover:scale-110 transition-transform duration-300">
                    <step.icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-lg font-bold text-vare-slate mb-2">{step.title}</h3>
                  <p className="text-vare-gray text-sm leading-relaxed">{step.desc}</p>
                  {i < service.process.length - 1 && (
                    <div className="hidden lg:block absolute top-8 right-0 translate-x-1/2">
                      <ArrowRight className="w-6 h-6 text-vare-purple/20" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ─── Technologies Section ─── */}
        <section ref={techRef} className="py-24 bg-vare-ice">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="section-header text-center mb-16">
              <span className="inline-flex items-center px-3 py-1 rounded-full bg-white text-vare-purple text-sm font-medium mb-4">
                <Code className="w-4 h-4 mr-1.5" /> Tech Stack
              </span>
              <h2 className="text-3xl md:text-4xl font-bold text-vare-slate mb-4">
                Tools & <span className="text-gradient">Technologies</span>
              </h2>
              <p className="text-vare-gray max-w-2xl mx-auto text-lg">
                The powerful tools and platforms we use to deliver exceptional {service.title.toLowerCase()} results.
              </p>
            </div>
            <div className="tech-pills flex flex-wrap justify-center gap-3 max-w-4xl mx-auto">
              {service.technologies.map((tech, i) => (
                <span
                  key={i}
                  className="tech-pill inline-flex items-center px-5 py-2.5 rounded-full text-sm font-medium bg-white text-vare-slate border border-gray-100 hover:border-vare-purple/30 hover:text-vare-purple hover:bg-vare-purple/5 shadow-sm hover:shadow-md transition-all duration-300 cursor-default"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>
        </section>

        {/* ─── FAQ Section ─── */}
        <section ref={faqRef} className="py-24 bg-white">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="section-header text-center mb-16">
              <span className="inline-flex items-center px-3 py-1 rounded-full bg-vare-ice text-vare-purple text-sm font-medium mb-4">
                <BookOpen className="w-4 h-4 mr-1.5" /> FAQ
              </span>
              <h2 className="text-3xl md:text-4xl font-bold text-vare-slate mb-4">
                Frequently Asked <span className="text-gradient">Questions</span>
              </h2>
              <p className="text-vare-gray max-w-2xl mx-auto text-lg">
                Common questions about our {service.title.toLowerCase()} service.
              </p>
            </div>
            <div className="faq-list space-y-4">
              {service.faqs.map((faq, i) => (
                <div
                  key={i}
                  className="faq-item rounded-2xl border border-gray-100 overflow-hidden transition-all duration-300 hover:border-vare-purple/20 hover:shadow-lg hover:shadow-purple-500/5"
                >
                  <button
                    onClick={() => setOpenFaq(openFaq === i ? null : i)}
                    className="w-full flex items-center justify-between p-6 text-left"
                    aria-expanded={openFaq === i}
                  >
                    <span className="text-base font-semibold text-vare-slate pr-4">{faq.question}</span>
                    <span className={`flex-shrink-0 w-8 h-8 rounded-full bg-vare-ice flex items-center justify-center transition-all duration-300 ${openFaq === i ? 'bg-vare-purple text-white' : 'text-vare-purple'}`}>
                      <ChevronDown className={`w-4 h-4 transition-transform duration-300 ${openFaq === i ? 'rotate-180' : ''}`} />
                    </span>
                  </button>
                  <div
                    className={`overflow-hidden transition-all duration-400 ease-in-out ${openFaq === i ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'}`}
                  >
                    <div className="px-6 pb-6 text-vare-gray text-sm leading-relaxed">
                      {faq.answer}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ─── CTA Section (Service-Specific) ─── */}
        <section ref={ctaRef} className="relative py-24 overflow-hidden bg-white">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="cta-anim relative rounded-3xl overflow-hidden opacity-0" style={{ willChange: 'auto' }}>
              <div className={`absolute inset-0 bg-gradient-to-r ${service.color}`} />
              <div className="absolute inset-0 bg-black/20" />
              <div className="absolute top-0 right-0 w-80 h-80 bg-white/5 rounded-full -translate-y-1/3 translate-x-1/3" />
              <div className="absolute bottom-0 left-0 w-60 h-60 bg-white/5 rounded-full translate-y-1/3 -translate-x-1/3" />
              <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-0">
                {/* Left - Content */}
                <div className="p-10 sm:p-12 lg:p-14 flex flex-col justify-center">
                  <div className="w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-sm flex items-center justify-center mb-6">
                    <service.icon className="w-7 h-7 text-white" />
                  </div>
                  <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4 leading-tight">
                    Ready to Elevate Your Business with {service.title}?
                  </h2>
                  <p className="text-white/75 text-base leading-relaxed mb-8">
                    Get a personalized strategy and project roadmap tailored to your goals. Our {service.title.toLowerCase()} specialists are standing by to help.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <Link
                      href="/contact"
                      className="inline-flex items-center justify-center px-7 py-3.5 text-base font-semibold text-vare-purple bg-white rounded-xl hover:shadow-2xl hover:shadow-white/25 transform hover:-translate-y-1 transition-all duration-300"
                    >
                      Get a Free Quote <ArrowRight className="ml-2 w-4 h-4" />
                    </Link>
                    <Link
                      href="/services"
                      className="inline-flex items-center justify-center px-7 py-3.5 text-base font-medium text-white border-2 border-white/25 rounded-xl hover:bg-white/10 transition-all duration-300"
                    >
                      All Services <Layers className="ml-2 w-4 h-4" />
                    </Link>
                  </div>
                </div>
                {/* Right - Stats */}
                <div className="p-10 sm:p-12 lg:p-14 bg-black/10 backdrop-blur-sm flex items-center">
                  <div className="grid grid-cols-2 gap-6 w-full">
                    <div className="bg-white/10 rounded-xl p-5 backdrop-blur-sm border border-white/10">
                      <div className="text-3xl font-bold text-white mb-1">500+</div>
                      <div className="text-white/60 text-sm">{service.title.split(' ')[0]} Projects</div>
                    </div>
                    <div className="bg-white/10 rounded-xl p-5 backdrop-blur-sm border border-white/10">
                      <div className="text-3xl font-bold text-white mb-1">98%</div>
                      <div className="text-white/60 text-sm">Client Satisfaction</div>
                    </div>
                    <div className="bg-white/10 rounded-xl p-5 backdrop-blur-sm border border-white/10">
                      <div className="text-3xl font-bold text-white mb-1">24h</div>
                      <div className="text-white/60 text-sm">Response Time</div>
                    </div>
                    <div className="bg-white/10 rounded-xl p-5 backdrop-blur-sm border border-white/10">
                      <div className="text-3xl font-bold text-white mb-1">Free</div>
                      <div className="text-white/60 text-sm">Consultation</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
