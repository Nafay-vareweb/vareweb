'use client';

import { useEffect, useRef } from 'react';
import Link from 'next/link';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { MapPin, Phone, Mail, ArrowUp, Facebook, Twitter, Linkedin, Instagram } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const footerLinks = {
  services: [
    { name: 'Custom Web Design', href: '/services/custom-web-design' },
    { name: 'Mobile App Development', href: '/services/mobile-app-development' },
    { name: 'SEO & Rankings', href: '/services/search-engine-optimization' },
    { name: 'GHL Automation', href: '/services/ghl-development' },
    { name: 'eCommerce Stores', href: '/services/ecommerce-development' },
    { name: 'Digital Marketing & PPC', href: '/services/digital-marketing' },
    { name: 'Social Media Management', href: '/services/social-media-management' },
    { name: 'Brand Identity & Logo', href: '/services/brand-identity-design' },
    { name: 'UX/UI Design', href: '/services/ux-ui-design' },
    { name: 'Custom Software Development', href: '/services/custom-software-development' },
    { name: 'Content Writing & Strategy', href: '/services/content-writing-strategy' },
    { name: 'Cloud Solutions & Hosting', href: '/services/cloud-solutions-hosting' },
  ],
  company: [
    { name: 'Who We Are', href: '/about' },
    { name: 'Our Work', href: '/portfolio' },
    { name: 'Pricing Plans', href: '/pricing' },
    { name: 'Insights & Blog', href: '/blog' },
    { name: 'Join Our Team', href: '/careers' },
    { name: 'Get In Touch', href: '/contact' },
  ],
  legal: [
    { name: 'Privacy Policy', href: '/privacy' },
    { name: 'Terms of Service', href: '/terms' },
  ],
};

export default function Footer() {
  const footerRef = useRef<HTMLElement>(null);

  useEffect(() => {
    if (footerRef.current) {
      gsap.fromTo(
        footerRef.current.querySelectorAll('.footer-animate'),
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          stagger: 0.1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: footerRef.current,
            start: 'top 80%',
          },
        }
      );
    }

    const scrollToTop = () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    const btn = document.getElementById('scroll-top-btn');
    if (btn) {
      btn.addEventListener('click', scrollToTop);
    }
    return () => {
      if (btn) btn.removeEventListener('click', scrollToTop);
    };
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer ref={footerRef} className="relative bg-vare-slate text-white overflow-hidden">
      {/* Decorative gradient */}
      <div className="absolute top-0 left-0 right-0 h-1 gradient-purple" />

      {/* Main Footer */}
      <div className="border-t border-white/10 py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
            {/* Brand */}
            <div className="footer-animate">
              <Link href="/" className="flex items-center space-x-2 mb-4">
                <div className="w-10 h-10 gradient-purple rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-xl">V</span>
                </div>
                <span className="text-xl font-bold">
                  Vare<span className="text-vare-purple-light">Web</span>
                </span>
              </Link>
              <p className="text-white/70 text-sm leading-relaxed mb-6">
                Award-winning digital agency delivering creative branding, stunning websites,
                and automated growth solutions that drive real results for businesses worldwide.
              </p>
              <div className="flex space-x-3">
                {[Facebook, Twitter, Linkedin, Instagram].map((Icon, i) => (
                  <a
                    key={i}
                    href="#"
                    className="w-9 h-9 rounded-lg bg-white/5 hover:bg-vare-purple flex items-center justify-center text-white/70 hover:text-white transition-all duration-300"
                  >
                    <Icon className="w-4 h-4" />
                  </a>
                ))}
              </div>
            </div>

            {/* Services */}
            <div className="footer-animate">
              <h3 className="text-sm font-semibold uppercase tracking-wider mb-4 !text-white">Explore</h3>
              <ul className="space-y-2.5">
                {footerLinks.services.map((link) => (
                  <li key={link.name}>
                    <Link
                      href={link.href}
                      className="text-white/70 hover:text-vare-gold text-sm transition-colors duration-200"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Company */}
            <div className="footer-animate">
              <h3 className="text-sm font-semibold uppercase tracking-wider mb-4 !text-white">What We Do</h3>
              <ul className="space-y-2.5">
                {footerLinks.company.map((link) => (
                  <li key={link.name}>
                    <Link
                      href={link.href}
                      className="text-white/70 hover:text-vare-gold text-sm transition-colors duration-200"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Legal + Contact */}
            <div className="footer-animate">
              <h3 className="text-sm font-semibold uppercase tracking-wider mb-4 !text-white">Information</h3>
              <ul className="space-y-2.5 mb-6">
                {footerLinks.legal.map((link) => (
                  <li key={link.name}>
                    <Link
                      href={link.href}
                      className="text-white/70 hover:text-vare-gold text-sm transition-colors duration-200"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
              <h3 className="text-sm font-semibold uppercase tracking-wider mb-4 !text-white">Reach Us</h3>
              <ul className="space-y-3">
                <li className="flex items-start space-x-3">
                  <MapPin className="w-4 h-4 text-vare-purple-light mt-1 flex-shrink-0" />
                  <span className="text-white/70 text-sm">5400 Preston Oaks Rd, Dallas, TX 75254, USA</span>
                </li>
                <li className="flex items-center space-x-3">
                  <Phone className="w-4 h-4 text-vare-purple-light flex-shrink-0" />
                  <a href="tel:+16592006383" className="text-white/70 hover:text-vare-purple-light text-sm transition-colors">
                    +1 659 200 6383
                  </a>
                </li>
                <li className="flex items-center space-x-3">
                  <Mail className="w-4 h-4 text-vare-purple-light flex-shrink-0" />
                  <a href="mailto:contact@vareweb.com" className="text-white/70 hover:text-vare-purple-light text-sm transition-colors">
                    contact@vareweb.com
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/10 py-6 px-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between">
          <p className="text-white/50 text-sm">
            &copy; {new Date().getFullYear()} VareWeb. All Rights Reserved.
          </p>
          <p className="text-white/50 text-sm mt-2 md:mt-0">
            Crafted with passion &amp; precision.
          </p>
        </div>
      </div>

      {/* Scroll to Top */}
      <button
        id="scroll-top-btn"
        onClick={scrollToTop}
        className="fixed bottom-8 right-8 z-50 w-12 h-12 gradient-purple rounded-full flex items-center justify-center text-white shadow-lg shadow-purple-500/25 hover:shadow-xl hover:shadow-purple-500/40 transform hover:-translate-y-1 transition-all duration-300"
      >
        <ArrowUp className="w-5 h-5" />
      </button>
    </footer>
  );
}
