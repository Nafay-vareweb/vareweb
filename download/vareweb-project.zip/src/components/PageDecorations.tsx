'use client';

import { useEffect, useRef } from 'react';
import gsap from 'gsap';

interface FloatingShape {
  id: number;
  type: 'circle' | 'square' | 'triangle' | 'hexagon' | 'ring';
  size: number;
  top: string;
  left: string;
  opacity: number;
  color: string;
  duration: string;
  delay: string;
}

const shapes: FloatingShape[] = [
  { id: 0, type: 'circle', size: 40, top: '8%', left: '5%', opacity: 0.06, color: '#7c4dbb', duration: '20s', delay: '0s' },
  { id: 1, type: 'square', size: 28, top: '20%', left: '92%', opacity: 0.05, color: '#5b2d9e', duration: '25s', delay: '2s' },
  { id: 2, type: 'triangle', size: 32, top: '45%', left: '3%', opacity: 0.07, color: '#f59e0b', duration: '18s', delay: '4s' },
  { id: 3, type: 'ring', size: 50, top: '15%', left: '88%', opacity: 0.04, color: '#7c4dbb', duration: '22s', delay: '1s' },
  { id: 4, type: 'circle', size: 20, top: '65%', left: '7%', opacity: 0.05, color: '#f59e0b', duration: '28s', delay: '3s' },
  { id: 5, type: 'hexagon', size: 24, top: '80%', left: '90%', opacity: 0.06, color: '#5b2d9e', duration: '24s', delay: '5s' },
  { id: 6, type: 'square', size: 18, top: '35%', left: '95%', opacity: 0.04, color: '#7c4dbb', duration: '19s', delay: '2s' },
  { id: 7, type: 'ring', size: 36, top: '70%', left: '4%', opacity: 0.05, color: '#f59e0b', duration: '23s', delay: '4s' },
];

export default function PageDecorations() {
  const containerRef = useRef<HTMLDivElement>(null);
  const shapeRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduced) return;

    shapeRefs.current.forEach((el, i) => {
      if (!el) return;
      // GSAP continuous floating animation
      gsap.to(el, {
        y: `+=${12 + (i % 3) * 8}`,
        x: `+=${(i % 2 === 0 ? 1 : -1) * (5 + (i % 4) * 3)}`,
        rotation: (i % 2 === 0 ? 90 : -90),
        duration: 2.5 + i * 0.4,
        ease: 'sine.inOut',
        yoyo: true,
        repeat: -1,
        delay: parseFloat(shapes[i]?.delay || '0'),
        force3D: true,
      });
    });
  }, []);

  const getShapeStyle = (shape: FloatingShape) => {
    const base: React.CSSProperties = {
      position: 'absolute',
      top: shape.top,
      left: shape.left,
      width: shape.size,
      height: shape.size,
      opacity: shape.opacity,
      pointerEvents: 'none',
    };

    switch (shape.type) {
      case 'circle':
        return { ...base, borderRadius: '50%', background: `radial-gradient(circle, ${shape.color}, ${shape.color}33)` };
      case 'square':
        return { ...base, borderRadius: '4px', background: `linear-gradient(135deg, ${shape.color}, ${shape.color}33)` };
      case 'triangle':
        return { ...base, background: `linear-gradient(135deg, ${shape.color}, ${shape.color}33)`, clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)' };
      case 'hexagon':
        return { ...base, borderRadius: '30%', background: `linear-gradient(135deg, ${shape.color}, ${shape.color}33)` };
      case 'ring':
        return { ...base, borderRadius: '50%', border: `2px solid ${shape.color}`, background: 'transparent' };
      default:
        return base;
    }
  };

  return (
    <div ref={containerRef} className="fixed inset-0 pointer-events-none z-0" aria-hidden="true">
      {shapes.map((shape) => (
        <div
          key={shape.id}
          ref={(el) => { shapeRefs.current[shape.id] = el; }}
          style={getShapeStyle(shape)}
        />
      ))}
    </div>
  );
}
