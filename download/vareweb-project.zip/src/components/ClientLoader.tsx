'use client';

import { useState, useCallback, useEffect, useRef, createContext, useContext } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import PageLoader from '@/components/PageLoader';

// Context to allow programmatic navigation with loader
interface NavigationContextType {
  navigateWithLoader: (href: string) => void;
}

export const NavigationContext = createContext<NavigationContextType>({
  navigateWithLoader: () => {},
});

export function useNavigationLoader() {
  return useContext(NavigationContext);
}

export default function ClientLoader({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const [showLoader, setShowLoader] = useState(true);
  const prevPathRef = useRef(pathname);
  const isNavigating = useRef(false);
  // Store pathname in a ref so click handler always has the latest value (no stale closure)
  const pathnameRef = useRef(pathname);
  const initialLoadDone = useRef(false);

  // Keep pathnameRef in sync
  useEffect(() => {
    pathnameRef.current = pathname;
  }, [pathname]);

  const handleLoaderComplete = useCallback(() => {
    setShowLoader(false);
    initialLoadDone.current = true;
  }, []);

  // Show loader on route change (works for both programmatic nav and link clicks)
  useEffect(() => {
    if (prevPathRef.current === pathname) return;
    prevPathRef.current = pathname;

    window.scrollTo({ top: 0 });

    if (isNavigating.current) {
      // Route changed after our programmatic navigation - already showing loader, just hide after delay
      const timer = setTimeout(() => {
        setShowLoader(false);
        isNavigating.current = false;
      }, 500);
      return () => clearTimeout(timer);
    } else {
      // Browser back/forward or direct URL change not triggered by our click handler
      const timer = setTimeout(() => {
        setShowLoader(false);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [pathname]);

  // Intercept all link clicks globally
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const anchor = target.closest('a');
      if (!anchor) return;

      const href = anchor.getAttribute('href');
      if (!href) return;

      // Only intercept internal navigation links
      if (href.startsWith('http') || href.startsWith('#') || href.startsWith('mailto:') || href.startsWith('tel:') || href.startsWith('/api/')) return;

      // Use ref instead of closure variable to avoid stale pathname
      const currentPath = pathnameRef.current;

      // Same page - don't show loader
      if (href === currentPath) return;

      // Mark as navigating and show loader
      e.preventDefault();
      isNavigating.current = true;
      window.scrollTo({ top: 0 });
      setShowLoader(true);

      // Navigate after a brief delay so the loader shows
      setTimeout(() => {
        router.push(href);
      }, 100);
    };

    document.addEventListener('click', handleClick, true);
    return () => document.removeEventListener('click', handleClick, true);
  }, [router]); // Remove pathname from deps - we use pathnameRef instead

  // Listen for browser back/forward (popstate)
  useEffect(() => {
    const handlePopState = () => {
      // Show loader immediately on popstate
      setShowLoader(true);
      window.scrollTo({ top: 0 });
      // The pathname useEffect will detect the route change and handle cleanup
      // Fallback: hide loader after timeout in case pathname doesn't change
      setTimeout(() => {
        setShowLoader(false);
      }, 600);
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigateWithLoader = useCallback((href: string) => {
    isNavigating.current = true;
    window.scrollTo({ top: 0 });
    setShowLoader(true);
    setTimeout(() => {
      router.push(href);
    }, 100);
  }, [router]);

  return (
    <NavigationContext.Provider value={{ navigateWithLoader }}>
      {showLoader && (
        <PageLoader onComplete={handleLoaderComplete} />
      )}
      <div style={{ opacity: showLoader ? 0 : 1, transition: 'opacity 0.2s ease' }}>
        {children}
      </div>
    </NavigationContext.Provider>
  );
}
